﻿using System;
using System.Net;

namespace VendorSupport.Common
{
    public class CRUDMessage
    {
        public string Message { get; set; }
        public Exception Ex { get; set; }
        public EnumMessageStutus MessageStutus { get; set; }
        public HttpStatusCode HTTPStatus { get; set; }
        public dynamic EntityObject { get; set; }

        public CRUDMessage(string message = null)
        {
            MessageStutus = EnumMessageStutus.Valid;
            HTTPStatus = HttpStatusCode.OK;
            Message =  StringConstants.CRUD_OPERATION_SUCESS;
            if (!string.IsNullOrEmpty(message))
                Message = message;
        }
         
    }
}
