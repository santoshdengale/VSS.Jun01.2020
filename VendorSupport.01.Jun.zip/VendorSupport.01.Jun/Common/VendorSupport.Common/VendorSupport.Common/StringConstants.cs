﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendorSupport.Common
{
    public static class StringConstants
    {
        public static string APPLOCATION_NAME = "Vendor Mangement System";

        public static string APPLOCATION_TITLE = "Vendor Mangement System";

        public static string CRUD_OPERATION_SUCESS = "CRUD Operation Sucess";

        public static string RECORD_CREATED_UPDTAE_SUCESSFULLY = "Record Created/Updated Successfully"; 

        public static string RECORD_DELETE_SUCESSFULLY = "Record Deleted Successfully";

        public static string RECORD_CREATED_UPDATE_FAILED = "Record  Created/Updated Failed";

        public static string RECORD_DELETE_FAILED = "Record Deleted Failed";

        public static string RECORD_ALREADY_EXIST = "Record Already Exist, Please provide another name / entity";
    }
}
