﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendorSupport.Common
{
    public enum EnumMessageStutus
    {
        Valid = 1,
        Invalid = 2,
    }

    public enum EnumUserType
    {
        Administrator = 1,
        Vendor=2,
        System = 3,
        User = 4
    }

    public enum EnumCommunicationType
    {
        Residiential = 1,
        Office = 2, 
    }

    public enum EnumSex
    {
        Male = 1,
        FeMale = 2,
    }
}
