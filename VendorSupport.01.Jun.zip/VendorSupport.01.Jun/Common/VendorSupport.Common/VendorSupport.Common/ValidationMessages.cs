﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendorSupport.Common
{
    public struct ValidationMessages
    {
        public  const string INPUT_VALIDATE_NAME= "Please enter/select Name";

        public const string INPUT_VALIDATE_CONFIRMED_PASSWORD = "The password and confirmation password do not match.";


    }
}
