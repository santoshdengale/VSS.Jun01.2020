﻿using System.ComponentModel.DataAnnotations;
using VendorSupport.Extensions;

namespace VendorSupport.Entities
{
    public abstract class BaseEntity
    {
        [Display(Name = "User code")]
        public decimal? UserCode { get; set; } // UserCode

        [Required]
        [MaxLength(8)]
        [Display(Name = "Row version")]
        public byte[] RowVersion { get; set; } // RowVersion (length: 8)

        [Display(Name = "Create by")]
        public decimal? CreateBy { get; set; } // CreateBy

        [DataType(DataType.DateTime)]
        [Display(Name = "Created date")]
        public System.DateTime? CreatedDate { get; set; } // CreatedDate

        [Display(Name = "Modified by")]
        public decimal? ModifiedBy { get; set; } // ModifiedBy

        [DataType(DataType.DateTime)]
        [Display(Name = "Modified date")]
        public System.DateTime? ModifiedDate { get; set; } // ModifiedDate

        public BaseEntity()
        {
            RowVersion = RowVersion.ValidateRawVersion();
            CreatedDate = System.DateTime.Now; // CreatedDate.Value.ValidateDate();
            ModifiedDate = System.DateTime.Now; //ModifiedDate.Value.ValidateDate();
            CreateBy = CreateBy.ValidateUser();
            ModifiedBy = ModifiedBy.ValidateUser();
            UserCode = UserCode.ValidateUser();
        }
    }
}
