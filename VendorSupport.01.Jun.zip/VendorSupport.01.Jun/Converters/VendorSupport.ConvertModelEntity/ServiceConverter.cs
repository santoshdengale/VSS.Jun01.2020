﻿using System.Collections.Generic;
using VendorSupport.Entities;
using VendorSupport.Extensions;
using VendorSupport.Models; 

namespace VendorSupport.ConvertModelEntity
{
    public class ServiceConverter : BaseConveters
    {
        public static ServiceDetailModel Convert(ServiceDetail entity)
        {
            ServiceDetailModel model = new ServiceDetailModel(); 
            model.Code = entity.Code;
            model.Name = entity.Name;
            CommonConverter(model, entity);

            return model;
        }

        public static ServiceDetail Convert(ServiceDetailModel model)
        {
            ServiceDetail entity = new ServiceDetail();  
            entity.Code = model.Code;
            entity.Name = model.Name;

            CommonConverter(entity, model);

            return entity;
        }

        public static IEnumerable<ServiceDetailModel> Convert(ICollection<ServiceDetail> entites)
        {
            ICollection<ServiceDetailModel> models = new List<ServiceDetailModel>();
            foreach (ServiceDetail entity in entites)
                models.Add(Convert(entity));
            return models;
        }

        public static IEnumerable<ServiceDetail> Convert(ICollection<ServiceDetailModel> models)
        {
            ICollection<ServiceDetail> entites = new List<ServiceDetail>();
            foreach (ServiceDetailModel model in models)
                entites.Add(Convert(model));
            return entites;
        }


        public static IEnumerable<ServiceDetailModel> Convert(IEnumerable<ServiceDetail> entites)
        {
            ICollection<ServiceDetailModel> models = new List<ServiceDetailModel>();
            foreach (ServiceDetail entity in entites)
                models.Add(Convert(entity));
            return models;
        }

        public static IEnumerable<ServiceDetail> Convert(IEnumerable<ServiceDetailModel> models)
        {
            ICollection<ServiceDetail> entites = new List<ServiceDetail>();
            foreach (ServiceDetailModel model in models)
                entites.Add(Convert(model));
            return entites;
        }

    }
}
