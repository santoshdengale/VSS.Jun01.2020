﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendorSupport.Entities;
using VendorSupport.Models;
using VendorSupport.Extensions;

namespace VendorSupport.ConvertModelEntity
{
    public class UserTypeConverter : BaseConveters
    {
        public static UserTypeDetailModel Convert(UserTypeDetail entity)
        {
            UserTypeDetailModel model = new UserTypeDetailModel();
            //model.CreateBy = entity.CreateBy.ValidateUser();
            //model.CreatedDate = entity.CreatedDate.Value.ValidateDate();
            //model.ModifiedBy = entity.ModifiedBy.ValidateUser();
            //model.ModifiedDate = entity.ModifiedDate.Value.ValidateDate();
            //model.RowVersion = entity.RowVersion.ValidateRaw();
            model.UserCode = entity.UserCode;
            model.UserTypeCode = entity.Code.ValidateUser();
            model.UserTypeName = entity.Name;
            CommonConverter(model, entity);

            return model;
        }

        public static UserTypeDetail Convert(UserTypeDetailModel model)
        {
            UserTypeDetail entity = new UserTypeDetail();

            //entity.CreateBy = model.CreateBy.ValidateUser();
            //entity.CreatedDate = model.CreatedDate.Value.ValidateDate();
            //entity.ModifiedBy = model.ModifiedBy.ValidateUser(); 
            //entity.ModifiedDate = model.ModifiedDate.Value.ValidateDate();
            //entity.RowVersion = model.RowVersion.ValidateRaw();

            entity.UserCode = model.UserCode;
            entity.Code = model.UserTypeCode.ValidateUser();
            entity.Name = model.UserTypeName;

            CommonConverter(entity, model);

            return entity;
        }

        public static IEnumerable<UserTypeDetailModel> Convert(ICollection<UserTypeDetail> entites)
        {
            ICollection<UserTypeDetailModel> models = new List<UserTypeDetailModel>();
            foreach (UserTypeDetail entity in entites)
                models.Add(Convert(entity));
            return models;
        }

        public static IEnumerable<UserTypeDetail> Convert(ICollection<UserTypeDetailModel> models)
        {
            ICollection<UserTypeDetail> entites = new List<UserTypeDetail>();
            foreach (UserTypeDetailModel model in models)
                entites.Add(Convert(model));
            return entites;
        }


        public static IEnumerable<UserTypeDetailModel> Convert(IEnumerable<UserTypeDetail> entites)
        {
            ICollection<UserTypeDetailModel> models = new List<UserTypeDetailModel>();
            foreach (UserTypeDetail entity in entites)
                models.Add(Convert(entity));
            return models;
        }

        public static IEnumerable<UserTypeDetail> Convert(IEnumerable<UserTypeDetailModel> models)
        {
            ICollection<UserTypeDetail> entites = new List<UserTypeDetail>();
            foreach (UserTypeDetailModel model in models)
                entites.Add(Convert(model));
            return entites;
        }

    }
}
