﻿using System.Collections.Generic;
using VendorSupport.Entities;
using VendorSupport.Extensions;
using VendorSupport.Models;

namespace VendorSupport.ConvertModelEntity
{
    public class UserConverter : BaseConveters
    {
        public static UserDetailModel Convert(UserDetail entity)
        {
            try
            {

                UserDetailModel model = new UserDetailModel();
                model.Code = entity.Code;

                model.CommCode = entity.CommCode;
                if (entity.CommunicationDetail != null)
                    model.CommunicationDetail = CommunicationConverter.Convert(entity.CommunicationDetail);

                model.PersonalCode = entity.Code;
                if (entity.PersonalDetail != null)
                    model.PersonalDetail = PersonalConverter.Convert(entity.PersonalDetail);

                model.UPassword = entity.UPassword;
                model.UserCode = entity.UserCode;
                model.Name = entity.Name;
                model.UserTypeCode = entity.UserTypeCode.ToString();
                if (entity.UserTypeDetail != null)
                    model.UserTypeDetail = UserTypeConverter.Convert(entity.UserTypeDetail);
                CommonConverter(model, entity);
                return model;
            }
            catch (System.Exception ex)
            {
                throw;
            }
        }

        public static UserDetail Convert(UserDetailModel model)
        {
            try
            {
                UserDetail entity = new UserDetail();

                entity.CommCode = model.CommCode;
                if (model.CommunicationDetail != null)
                    entity.CommunicationDetail = CommunicationConverter.Convert(model.CommunicationDetail);

                entity.PersonalCode = model.PersonalCode;
                if (model.PersonalDetail != null)
                    entity.PersonalDetail = PersonalConverter.Convert(model.PersonalDetail);

                entity.Name = model.Name;
                entity.UPassword = model.UPassword;
                entity.UserCode = model.UserCode;
                entity.UserTypeCode = System.Convert.ToDecimal(model.UserTypeCode);
                entity.UserTypeDetail = UserTypeConverter.Convert(model.UserTypeDetail);
                CommonConverter(entity, model);
                return entity;
            }
            catch (System.Exception ex)
            {
                throw;
            }

        }

        public static ICollection<UserDetailModel> Convert(ICollection<UserDetail> entites)
        {
            ICollection<UserDetailModel> models = new List<UserDetailModel>();
            foreach (UserDetail entity in entites)
                models.Add(Convert(entity));
            return models;
        }

        public static ICollection<UserDetail> Convert(ICollection<UserDetailModel> models)
        {
            ICollection<UserDetail> entites = new List<UserDetail>();
            foreach (UserDetailModel model in models)
                entites.Add(Convert(model));
            return entites;
        }

        public static IEnumerable<UserDetailModel> Convert(IEnumerable<UserDetail> entites)
        {
            ICollection<UserDetailModel> models = new List<UserDetailModel>();
            foreach (UserDetail entity in entites)
                models.Add(Convert(entity));
            return models;
        }

        public static IEnumerable<UserDetail> Convert(IEnumerable<UserDetailModel> models)
        {
            ICollection<UserDetail> entites = new List<UserDetail>();
            foreach (UserDetailModel model in models)
                entites.Add(Convert(model));
            return entites;
        }
    }
}
