﻿using System;
using System.Collections.Generic;
using VendorSupport.Entities;
using VendorSupport.Models;

namespace VendorSupport.ConvertModelEntity
{
    public class CityConverter : BaseConveters
    {
        public static CityDetailModel Convert(CityDetail entity)
        {
            CityDetailModel model = new CityDetailModel();
            try
            {
                model.Code = entity.Code;
                model.Name = entity.Name;
                model.StateCode = System.Convert.ToString(entity.StateCode);
                model.StateDetail = StateConverter.Convert(entity.StateDetail);
                model.AreaDetails = AreaConverter.Convert(entity.AreaDetails) as ICollection<AreaDetailModel>;
                CommonConverter(model, entity);
            }
            catch (Exception ex)
            {

            }
            return model;
        }

        public static CityDetail Convert(CityDetailModel model)
        {
            CityDetail entity = new CityDetail();

            entity.Code = model.Code;
            entity.Name = model.Name;
            entity.StateDetail = StateConverter.Convert(model.StateDetail);
            entity.StateCode = System.Convert.ToDecimal(model.StateCode);
            entity.AreaDetails = AreaConverter.Convert(model.AreaDetails) as ICollection<AreaDetail>;

            CommonConverter(entity, model);

            return entity;
        }

        public static IEnumerable<CityDetailModel> Convert(ICollection<CityDetail> entites)
        {
            ICollection<CityDetailModel> models = new List<CityDetailModel>();
            foreach (CityDetail entity in entites)
                models.Add(Convert(entity));
            return models;
        }

        public static IEnumerable<CityDetail> Convert(ICollection<CityDetailModel> models)
        {
            ICollection<CityDetail> entites = new List<CityDetail>();
            foreach (CityDetailModel model in models)
                entites.Add(Convert(model));
            return entites;
        }


        public static IEnumerable<CityDetailModel> Convert(IEnumerable<CityDetail> entites)
        {
            ICollection<CityDetailModel> models = new List<CityDetailModel>();
            foreach (CityDetail entity in entites)
                models.Add(Convert(entity));
            return models;
        }

        public static IEnumerable<CityDetail> Convert(IEnumerable<CityDetailModel> models)
        {
            ICollection<CityDetail> entites = new List<CityDetail>();
            foreach (CityDetailModel model in models)
                entites.Add(Convert(model));
            return entites;
        }

    }
}
