﻿using System.Collections.Generic;
using VendorSupport.Entities;
using VendorSupport.Extensions;
using VendorSupport.Models;

namespace VendorSupport.ConvertModelEntity
{
    public class CountryConverter : BaseConveters
    {
        public static CountryDetailModel Convert(CountryDetail entity)
        {
            CountryDetailModel model = new CountryDetailModel();
            model.Code = entity.Code;
            model.Name = entity.Name;
            CommonConverter(model, entity);

            return model;
        }

        public static CountryDetail Convert(CountryDetailModel model)
        {
            
            CountryDetail entity = new CountryDetail();
            if (model == null) return entity;
                entity.Code = model.Code;
            entity.Name = model.Name;

            CommonConverter(entity, model);

            return entity;
        }

        public static IEnumerable<CountryDetailModel> Convert(ICollection<CountryDetail> entites)
        {
            ICollection<CountryDetailModel> models = new List<CountryDetailModel>();
            foreach (CountryDetail entity in entites)
                models.Add(Convert(entity));
            return models;
        }

        public static IEnumerable<CountryDetail> Convert(ICollection<CountryDetailModel> models)
        {
            ICollection<CountryDetail> entites = new List<CountryDetail>();
            foreach (CountryDetailModel model in models)
                entites.Add(Convert(model));
            return entites;
        }


        public static IEnumerable<CountryDetailModel> Convert(IEnumerable<CountryDetail> entites)
        {
            ICollection<CountryDetailModel> models = new List<CountryDetailModel>();
            foreach (CountryDetail entity in entites)
                models.Add(Convert(entity));
            return models;
        }

        public static IEnumerable<CountryDetail> Convert(IEnumerable<CountryDetailModel> models)
        {
            ICollection<CountryDetail> entites = new List<CountryDetail>();
            foreach (CountryDetailModel model in models)
                entites.Add(Convert(model));
            return entites;
        }

    }
}
