﻿using System;
using System.Collections.Generic;
using VendorSupport.Entities;
using VendorSupport.Models;

namespace VendorSupport.ConvertModelEntity
{
    public class AreaConverter : BaseConveters
    {
        public static AreaDetailModel Convert(AreaDetail entity)
        {
            AreaDetailModel model = new AreaDetailModel();
            try
            {
                model.Code = entity.Code;
                model.Name = entity.Name;
                // model.CityDetail = CityConverter.Convert(entity.CityDetail);

               // model.CityDetail.AreaDetails = entity.CityDetail.AreaDetails;
                model.CityDetail.Code = entity.CityDetail.Code;
                model.CityDetail.Name = entity.CityDetail.Name;

                model.CityCode = System.Convert.ToString(entity.CityCode);
                CommonConverter(model, entity);
            }
            catch (Exception ex)
            {
                throw;
            }
            return model;
        }

        public static AreaDetail Convert(AreaDetailModel model)
        {
            AreaDetail entity = new AreaDetail();
            try
            {
                entity.Code = model.Code;
                entity.Name = model.Name;
                entity.CityDetail = CityConverter.Convert(model.CityDetail);
                // entity.CountryDetail = CountryConverter.Convert(model.CountryDetail);
                entity.CityCode = System.Convert.ToDecimal(model.CityCode);
                CommonConverter(entity, model);

            }
            catch (Exception ex)
            {
                throw;
            }

            return entity;
        }

        public static IEnumerable<AreaDetailModel> Convert(ICollection<AreaDetail> entites)
        {
            ICollection<AreaDetailModel> models = new List<AreaDetailModel>();
            foreach (AreaDetail entity in entites)
                models.Add(Convert(entity));
            return models;
        }

        public static IEnumerable<AreaDetail> Convert(ICollection<AreaDetailModel> models)
        {
            ICollection<AreaDetail> entites = new List<AreaDetail>();
            foreach (AreaDetailModel model in models)
                entites.Add(Convert(model));
            return entites;
        }


        public static IEnumerable<AreaDetailModel> Convert(IEnumerable<AreaDetail> entites)
        {
            ICollection<AreaDetailModel> models = new List<AreaDetailModel>();
            foreach (AreaDetail entity in entites)
                models.Add(Convert(entity));
            return models;
        }

        public static IEnumerable<AreaDetail> Convert(IEnumerable<AreaDetailModel> models)
        {
            ICollection<AreaDetail> entites = new List<AreaDetail>();
            foreach (AreaDetailModel model in models)
                entites.Add(Convert(model));
            return entites;
        }

    }
}