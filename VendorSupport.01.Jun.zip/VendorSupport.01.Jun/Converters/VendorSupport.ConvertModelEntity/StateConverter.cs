﻿using System;
using System.Collections.Generic;
using VendorSupport.Entities;
using VendorSupport.Models;

namespace VendorSupport.ConvertModelEntity
{
    public class StateConverter : BaseConveters
    {
        public static StateDetailModel Convert(StateDetail entity)
        {
            StateDetailModel model = new StateDetailModel();
            try
            {
                model.Code = entity.Code;
                model.Name = entity.Name;
                model.CountryCode = System.Convert.ToString(entity.CountryCode);
                model.CountryDetail = CountryConverter.Convert(entity.CountryDetail);
                CommonConverter(model, entity);
            }
            catch (Exception ex)
            {

            }
            return model;
        }

        public static StateDetail Convert(StateDetailModel model)
        {
            StateDetail entity = new StateDetail();

            entity.Code = model.Code;
            entity.Name = model.Name;
            entity.CountryCode = System.Convert.ToDecimal(model.CountryCode);
            entity.CountryDetail = CountryConverter.Convert(model.CountryDetail);

            CommonConverter(entity, model);

            return entity;
        }

        public static IEnumerable<StateDetailModel> Convert(ICollection<StateDetail> entites)
        {
            ICollection<StateDetailModel> models = new List<StateDetailModel>();
            foreach (StateDetail entity in entites)
                models.Add(Convert(entity));
            return models;
        }

        public static IEnumerable<StateDetail> Convert(ICollection<StateDetailModel> models)
        {
            ICollection<StateDetail> entites = new List<StateDetail>();
            foreach (StateDetailModel model in models)
                entites.Add(Convert(model));
            return entites;
        }


        public static IEnumerable<StateDetailModel> Convert(IEnumerable<StateDetail> entites)
        {
            ICollection<StateDetailModel> models = new List<StateDetailModel>();
            foreach (StateDetail entity in entites)
                models.Add(Convert(entity));
            return models;
        }

        public static IEnumerable<StateDetail> Convert(IEnumerable<StateDetailModel> models)
        {
            ICollection<StateDetail> entites = new List<StateDetail>();
            foreach (StateDetailModel model in models)
                entites.Add(Convert(model));
            return entites;
        }

    }
}
