﻿using System.Collections.Generic;
using VendorSupport.Entities;
using VendorSupport.Extensions;
using VendorSupport.Models;

namespace VendorSupport.ConvertModelEntity
{
    public class VendorConverter : BaseConveters
    {
        public static VendorDetailModel Convert(VendorDetail entity)
        {
            VendorDetailModel model = new VendorDetailModel();

            model.Code = entity.Code;
            model.CommCode = entity.CommCode;
            model.CommunicationDetail.Address1 = entity.CommunicationDetail.Address1;
            model.CommunicationDetail.Address2 = entity.CommunicationDetail.Address2;
            model.CommunicationDetail.Area1 = entity.CommunicationDetail.Area1;
            model.CommunicationDetail.Area2 = entity.CommunicationDetail.Area2;
            model.CommunicationDetail.Code = entity.CommunicationDetail.Code;
            model.CommunicationDetail.CommunicationType = entity.CommunicationDetail.CommunicationType;
            model.CommunicationDetail.Email1 = entity.CommunicationDetail.Email1;

            model.PersonalCode = entity.PersonalCode;
            model.PersonalDetail.Code = entity.PersonalDetail.Code;
            model.PersonalDetail.DateOfBirth = entity.PersonalDetail.DateOfBirth;
            model.PersonalDetail.FirstName = entity.PersonalDetail.FirstName;
            model.PersonalDetail.LastName = entity.PersonalDetail.LastName;
            model.PersonalDetail.MiddleName = entity.PersonalDetail.MiddleName;
            model.PersonalDetail.Sex = entity.PersonalDetail.Sex;
            model.PersonalDetail.UserCode = entity.PersonalDetail.UserCode;

            model.UserDetail.Name = entity.UserDetail.Name;
            model.UserDetail.UPassword = entity.UserDetail.UPassword;
            model.UserDetail.UserTypeCode = entity.UserDetail.UserTypeCode.ToString();
            CommonConverter(model, entity);
            return model;
        }

        public static VendorDetail Convert(VendorDetailModel model)
        {
            VendorDetail entity = new VendorDetail();
           
            entity.Code = model.Code;
            entity.CommCode = model.CommCode;
            entity.CommunicationDetail.Address1 = model.CommunicationDetail.Address1;
            entity.CommunicationDetail.Address2 = model.CommunicationDetail.Address2;
            entity.CommunicationDetail.Area1 = model.CommunicationDetail.Area1;
            entity.CommunicationDetail.Area2 = model.CommunicationDetail.Area2;
            entity.CommunicationDetail.Code = model.CommunicationDetail.Code;
            entity.CommunicationDetail.CommunicationType = model.CommunicationDetail.CommunicationType;
            entity.CommunicationDetail.Email1 = model.CommunicationDetail.Email1;

            entity.PersonalCode = model.PersonalCode;
            entity.PersonalDetail.Code = model.PersonalDetail.Code;
            entity.PersonalDetail.DateOfBirth = model.PersonalDetail.DateOfBirth;
            entity.PersonalDetail.FirstName = model.PersonalDetail.FirstName;
            entity.PersonalDetail.LastName = model.PersonalDetail.LastName;
            entity.PersonalDetail.MiddleName = model.PersonalDetail.MiddleName;
            entity.PersonalDetail.Sex = model.PersonalDetail.Sex;
            entity.PersonalDetail.UserCode = model.PersonalDetail.UserCode;
             
            entity.UserDetail.Name = model.UserDetail.Name;
            entity.UserDetail.UPassword = model.UserDetail.UPassword;
            entity.UserDetail.UserTypeCode = System.Convert.ToDecimal(model.UserDetail.UserTypeCode);

            CommonConverter(entity, model);
            return entity;
        }

        public static IEnumerable<VendorDetailModel> Convert(ICollection<VendorDetail> entites)
        {
            ICollection<VendorDetailModel> models = new List<VendorDetailModel>();
            foreach (VendorDetail entity in entites)
                models.Add(Convert(entity));
            return models;
        }

        public static IEnumerable<VendorDetail> Convert(ICollection<VendorDetailModel> models)
        {
            ICollection<VendorDetail> entites = new List<VendorDetail>();
            foreach (VendorDetailModel model in models)
                entites.Add(Convert(model));
            return entites;
        }


        public static IEnumerable<VendorDetailModel> Convert(IEnumerable<VendorDetail> entites)
        {
            ICollection<VendorDetailModel> models = new List<VendorDetailModel>();
            foreach (VendorDetail entity in entites)
                models.Add(Convert(entity));
            return models;
        }

        public static IEnumerable<VendorDetail> Convert(IEnumerable<VendorDetailModel> models)
        {
            ICollection<VendorDetail> entites = new List<VendorDetail>();
            foreach (VendorDetailModel model in models)
                entites.Add(Convert(model));
            return entites;
        }

    }
}
