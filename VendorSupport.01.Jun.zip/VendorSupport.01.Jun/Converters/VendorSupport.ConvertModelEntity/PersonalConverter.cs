﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendorSupport.Entities;
using VendorSupport.Models;
using VendorSupport.Extensions;

namespace VendorSupport.ConvertModelEntity
{
    public class PersonalConverter: BaseConveters
    {
        public static PersonalDetailModel Convert(PersonalDetail entity)
        {
            PersonalDetailModel model = new PersonalDetailModel();

            //model.CreateBy = entity.CreateBy.ValidateUser();
            //model.CreatedDate = entity.CreatedDate.Value.ValidateDate();
            //model.ModifiedBy = entity.ModifiedBy.ValidateUser();
            //model.ModifiedDate = entity.ModifiedDate.Value.ValidateDate();
            //model.RowVersion = entity.RowVersion.ValidateRaw();
            //model.UserCode = entity.UserCode;
            //model.UserTypeCode = entity.UserTypeCode.ValidateUserType();
            //model.UserTypeName = entity.UserTypeName;


            model.DateOfBirth = entity.DateOfBirth.Value;
            model.FirstName = entity.FirstName;
            model.LastName = entity.LastName;
            model.MiddleName = entity.MiddleName;
            model.Sex = entity.Sex;
            model.UserCode = entity.UserCode;
            //model.UserDetails = UserConverter.Convert(  entity.UserDetails);

            CommonConverter(model, entity);

            return model;
        }

        public static PersonalDetail Convert(PersonalDetailModel model)
        {
            PersonalDetail entity = new PersonalDetail();

            //entity.CreateBy = model.CreateBy.ValidateUser();
            //entity.CreatedDate = model.CreatedDate.Value.ValidateDate();
            //entity.ModifiedBy = model.ModifiedBy.ValidateUser();
            //entity.ModifiedDate = model.ModifiedDate.Value.ValidateDate();
            //entity.RowVersion = model.RowVersion.ValidateRaw();
            //entity.UserCode = model.UserCode;
            ////entity.UserTypeCode = model.UserTypeCode.ValidateUserType();
            ////entity.UserTypeName = model.UserTypeName; 
            
            entity.DateOfBirth = model.DateOfBirth;
            entity.FirstName = model.FirstName;
            entity.LastName = model.LastName;
            entity.MiddleName = model.MiddleName;
            entity.Sex = model.Sex;
            entity.UserCode = model.UserCode;

            entity.UserDetails = UserConverter.Convert(model.UserDetails);

            return entity;
        }

        public static IEnumerable<PersonalDetailModel> Convert(ICollection<PersonalDetail> entites)
        {
            ICollection<PersonalDetailModel> models = new List<PersonalDetailModel>();
            foreach (PersonalDetail entity in entites)
                models.Add(Convert(entity));
            return models;
        }

        public static IEnumerable<PersonalDetail> Convert(ICollection<PersonalDetailModel> models)
        {
            ICollection<PersonalDetail> entites = new List<PersonalDetail>();
            foreach (PersonalDetailModel model in models)
                entites.Add(Convert(model));
            return entites;
        }

        public static IEnumerable<PersonalDetailModel> Convert(IEnumerable<PersonalDetail> entites)
        {
            ICollection<PersonalDetailModel> models = new List<PersonalDetailModel>();
            foreach (PersonalDetail entity in entites)
                models.Add(Convert(entity));
            return models;
        }

        public static IEnumerable<PersonalDetail> Convert(IEnumerable<PersonalDetailModel> models)
        {
            ICollection<PersonalDetail> entites = new List<PersonalDetail>();
            foreach (PersonalDetailModel model in models)
                entites.Add(Convert(model));
            return entites;
        }
    }
}