﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendorSupport.Entities;
using VendorSupport.Models;
using VendorSupport.Extensions;

namespace VendorSupport.ConvertModelEntity
{
    public class CommunicationConverter : BaseConveters
    {

        public static CommunicationDetailModel Convert(CommunicationDetail entity)
        {
            CommunicationDetailModel model = new CommunicationDetailModel();
            //model.CreateBy = entity.CreateBy.ValidateUser();
            //model.CreatedDate = entity.CreatedDate.Value.ValidateDate();
            //model.ModifiedBy = entity.ModifiedBy.ValidateUser();
            //model.ModifiedDate = entity.ModifiedDate.Value.ValidateDate();
            //model.RowVersion = entity.RowVersion.ValidateRaw();
            //model.UserCode = entity.UserCode;

            model.Address1 = entity.Address1;
            model.Address2 = entity.Address2;
            model.Code = entity.Code;
            model.Email1 = entity.Email1;
            model.Mobile1 = entity.Mobile1;
            model.Mobile2 = entity.Mobile2;
            model.UserCode = entity.UserCode;
            //model.UserDetails = UserConverter.Convert(entity.u);

            CommonConverter(entity, model);
            return model;
        }

        public static CommunicationDetail Convert(CommunicationDetailModel model)
        {
            CommunicationDetail entity = new CommunicationDetail();

            //entity.CreateBy = model.CreateBy.ValidateUser();
            //entity.CreatedDate = model.CreatedDate.Value.ValidateDate();
            //entity.ModifiedBy = model.ModifiedBy.ValidateUser();
            //entity.ModifiedDate = model.ModifiedDate.Value.ValidateDate();
            //entity.RowVersion = model.RowVersion.ValidateRaw();
            //entity.UserCode = model.UserCode;

            entity.Address1 = model.Address1;
            entity.Address2 = model.Address2;
            entity.Code = model.Code;
            entity.Email1 = model.Email1;
            entity.Mobile1 = model.Mobile1;
            entity.Mobile2 = model.Mobile2;
            entity.UserCode = model.UserCode;
            //entity.UserDetails = UserConverter.Convert(model.UserDetails);

            CommonConverter(model, entity);
            return entity;
        }

        public static IEnumerable<CommunicationDetailModel> Convert(ICollection<CommunicationDetail> entites)
        {
            ICollection<CommunicationDetailModel> models = new List<CommunicationDetailModel>();
            foreach (CommunicationDetail entity in entites)
                models.Add(Convert(entity));
            return models;
        }

        public static IEnumerable<CommunicationDetail> Convert(ICollection<CommunicationDetailModel> models)
        {
            ICollection<CommunicationDetail> entites = new List<CommunicationDetail>();
            foreach (CommunicationDetailModel model in models)
                entites.Add(Convert(model));
            return entites;
        }

        public static IEnumerable<CommunicationDetailModel> Convert(IEnumerable<CommunicationDetail> entites)
        {
            ICollection<CommunicationDetailModel> models = new List<CommunicationDetailModel>();
            foreach (CommunicationDetail entity in entites)
                models.Add(Convert(entity));
            return models;
        }

        public static IEnumerable<CommunicationDetail> Convert(IEnumerable<CommunicationDetailModel> models)
        {
            ICollection<CommunicationDetail> entites = new List<CommunicationDetail>();
            foreach (CommunicationDetailModel model in models)
                entites.Add(Convert(model));
            return entites;
        }
    }
}
