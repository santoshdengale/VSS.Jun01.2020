﻿using VendorSupport.Entities;
using VendorSupport.Extensions;
using VendorSupport.Models;

namespace VendorSupport.ConvertModelEntity
{
    public abstract class BaseConveters
    {
        protected static void CommonConverter(BaseModel model, BaseEntity entity)
        {
            model.CreateBy = entity.CreateBy.ValidateUser();
            model.CreatedDate = entity.CreatedDate.Value.ValidateDate();
            model.ModifiedBy = entity.ModifiedBy.ValidateUser();
            model.ModifiedDate = entity.ModifiedDate.Value.ValidateDate();
            model.RowVersion = entity.RowVersion.ValidateRawVersion();
            model.UserCode = entity.UserCode.ValidateUser(); 
           // model.UserAuditCode = entity.UserCode.ValidateUser();
        }

        protected static void CommonConverter(BaseEntity entity, BaseModel model)
        {
            entity.CreateBy = model.CreateBy.ValidateUser();
            entity.CreatedDate = model.CreatedDate.Value.ValidateDate();
            entity.ModifiedBy = model.ModifiedBy.ValidateUser();
            entity.ModifiedDate = model.ModifiedDate.Value.ValidateDate();
            entity.RowVersion = model.RowVersion.ValidateRawVersion();
            entity.UserCode = model.UserCode.ValidateUser();
        }

        public static void CommonConverter(BaseModel model)
        {
            model.CreateBy = model.CreateBy.ValidateUser();
            model.CreatedDate = model.CreatedDate.Value.ValidateDate();
            model.ModifiedBy = model.ModifiedBy.ValidateUser();
            model.ModifiedDate = model.ModifiedDate.Value.ValidateDate();
            model.RowVersion = model.RowVersion.ValidateRawVersion();
        }

        public static void CommonConverter(BaseEntity entity)
        {
            entity.CreateBy = entity.CreateBy.ValidateUser();
            entity.CreatedDate = entity.CreatedDate.Value.ValidateDate();
            entity.ModifiedBy = entity.ModifiedBy.ValidateUser();
            entity.ModifiedDate = entity.ModifiedDate.Value.ValidateDate();
            entity.RowVersion = entity.RowVersion.ValidateRawVersion();
        }
    }
}
