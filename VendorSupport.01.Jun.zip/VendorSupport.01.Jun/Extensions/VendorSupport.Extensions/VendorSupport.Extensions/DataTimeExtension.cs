﻿using System;

namespace VendorSupport.Extensions
{
    public static class DataTimeExtension
    {
        public static DateTime ValidateDate(this DateTime dtTime)
        { 
            return (dtTime == DateTime.MaxValue || dtTime == DateTime.MinValue) ?
               DateTime.Now : dtTime; 
        }
    }
}
