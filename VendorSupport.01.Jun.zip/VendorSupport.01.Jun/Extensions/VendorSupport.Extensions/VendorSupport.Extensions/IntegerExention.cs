﻿using VendorSupport.Common;

namespace VendorSupport.Extensions
{
    public static class IntegerExention
    {
         
    }
}
