﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendorSupport.Extensions
{
    public static class ByteExtension
    {
        public static byte[] ValidateRawVersion(this byte[] rawVersion)
        {
         
            DateTime utcNow = DateTime.UtcNow;
            long utcNowAsLong = utcNow.ToBinary();
            byte[] utcNowBytes = BitConverter.GetBytes(utcNowAsLong);
            if (rawVersion == null)
                return utcNowBytes;
            else
                return rawVersion;
        }
    }
}
