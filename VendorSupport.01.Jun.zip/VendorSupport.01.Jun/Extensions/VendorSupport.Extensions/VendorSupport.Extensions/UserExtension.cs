﻿using VendorSupport.Common;

namespace VendorSupport.Extensions
{
    public static class UserExtension
    {
        public static int ValidateUser(this int userType)
        {
            return (userType == 0) ? (int)EnumUserType.Administrator : userType;
        }

        public static decimal? ValidateUser(this decimal? userType)
        {
            decimal? userTypeResult = (int)EnumUserType.Administrator;
            userTypeResult = userType == null ? userTypeResult : userType;
            //userTypeResult = userType == 0 ? userTypeResult : userType;
            return userTypeResult;
        }

        public static decimal ValidateUser(this decimal userType)
        {
            decimal userTypeResult = (int)EnumUserType.Administrator;
            userTypeResult = userType == 0 ? userTypeResult : userType;
            return userTypeResult;
        }

        public static decimal? ValidateUserType(this decimal? userType)
        {
            decimal? userTypeResult = (int)EnumUserType.Administrator;
            userTypeResult = userType == null ? userTypeResult : userType;
            //userTypeResult = userType == 0 ? userTypeResult : userType;
            return userTypeResult;
        }

        public static decimal ValidateUserType(this decimal userType)
        {
            decimal userTypeResult = (int)EnumUserType.Administrator;
            userTypeResult = userType == 0 ? userTypeResult : userType;
            return userTypeResult;
        }
    }
}
