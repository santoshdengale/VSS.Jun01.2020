﻿using VendorSupport.Entities;

namespace VendorSupport.EntityConfigs
{
    public abstract class BaseEntityConfig<T> : System.Data.Entity.ModelConfiguration.EntityTypeConfiguration<T> where T : BaseEntity
    {
        public BaseEntityConfig()
          
        {
        
            Property(x => x.UserCode).HasColumnName(@"UserCode").HasColumnType("numeric").IsOptional().HasPrecision(18, 0);
            Property(x => x.RowVersion).HasColumnName(@"RowVersion").HasColumnType("timestamp").IsRequired().IsFixedLength().HasMaxLength(8).IsRowVersion();
            Property(x => x.CreateBy).HasColumnName(@"CreateBy").HasColumnType("numeric").IsOptional().HasPrecision(18, 0);
            Property(x => x.CreatedDate).HasColumnName(@"CreatedDate").HasColumnType("datetime").IsOptional();
            Property(x => x.ModifiedBy).HasColumnName(@"ModifiedBy").HasColumnType("numeric").IsOptional().HasPrecision(18, 0);
            Property(x => x.ModifiedDate).HasColumnName(@"ModifiedDate").HasColumnType("datetime").IsOptional();
        }
    }
}