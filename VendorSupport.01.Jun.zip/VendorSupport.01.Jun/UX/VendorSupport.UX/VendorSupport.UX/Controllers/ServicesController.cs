﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using System.Web.Mvc;
using VendorSupport.Formatters;
using VendorSupport.Models;
using VendorSupport.ServicesProxies;

namespace VendorSupport.UX.Controllers
{
    public class ServicesController : BaseController
    {
        // GET: Service/Details/5
        public async Task<ActionResult> List()
        {
            List<ServiceDetailModel> models = null;
            using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                //API / Services / GetServices
                string jsonString = await httpClientWrap.GetStringAsync("API/Services/GetServices");
                models = JSonFormatter<List<ServiceDetailModel>>.Deserialize(Convert.ToString(jsonString));
            }
            return View(models);
        }

        // GET: Service/Details/5
        public ActionResult Read(int id)
        {
            return View();
        }

        // GET: Service/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Service/Create
        [HttpPost]
        public async Task<ActionResult> Create(ServiceDetailModel model)
        {
            if (!ModelState.IsValid)
                return View(model);
            try
            {
                using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
                {
                    string usrTypeJson = JSonFormatter<ServiceDetailModel>.Serialize(model);
                    HTTPResponseMessage = await httpClientWrap.PostAsyc("API/Services/PostService", usrTypeJson);
                }
                if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                    return RedirectToAction("List");
                else
                    return View(model);
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: Service/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            ServiceDetailModel ServiceDetail = null;
            using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                var jsonString = await httpClientWrap.GetStringAsync("API/Service/GetService/" + id.ToString());
                ServiceDetail = JSonFormatter<ServiceDetailModel>.Deserialize(Convert.ToString(jsonString));

            }
            return View(ServiceDetail);
        }

        // POST: Service/Edit/5
        [HttpPost]
        public async Task<ActionResult> Edit(ServiceDetailModel model)
        {
            try
            {
                using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
                {
                    string jsonObjectString = JSonFormatter<ServiceDetailModel>.Serialize(model);
                    HTTPResponseMessage = await httpClientWrap.PutAsyc("API/Service/PutService", jsonObjectString);
                }
                if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                    return RedirectToAction("List");
                else
                    return View(model);
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: Service/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Service/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public async static Task<List<SelectListItem>> GetServices()
        {
            List<SelectListItem> listItems = new List<SelectListItem>();
            List<ServiceDetailModel> models = null;
            using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                string jsonString = await httpClientWrap.GetStringAsync("API/Service/GetService");
                models = JSonFormatter<List<ServiceDetailModel>>.Deserialize(Convert.ToString(jsonString));
            }
            foreach (ServiceDetailModel model in models)
            {
                SelectListItem selectedItem = new SelectListItem();
                selectedItem.Text = model.Name;
                selectedItem.Value = model.Code.ToString();
                listItems.Add(selectedItem);
            }
            return listItems;
        }
    }
}
