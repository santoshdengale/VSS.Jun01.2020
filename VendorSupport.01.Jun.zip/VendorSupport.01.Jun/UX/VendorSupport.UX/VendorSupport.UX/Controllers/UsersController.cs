﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Mvc;
using VendorSupport.ConvertModelEntity;
using VendorSupport.Formatters;
using VendorSupport.Models;
using VendorSupport.ServicesProxies;

namespace VendorSupport.UX.Controllers
{
    public class UsersController : BaseController
    {
        public ActionResult ChangePassword()
        {
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> ChangePassword(UserDetailModel model)
        {
            try
            {
                using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
                {
                    string jsonDataModel = JSonFormatter<UserDetailModel>.Serialize(model); 
                    HTTPResponseMessage = await httpClientWrap.PostAsyc("API/Users/ChangeUserPassword", jsonDataModel);
                }
                if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                    return RedirectToAction("Administrator", "AdminDashBoard");
                else
                {
                    model.UserTypeListItems = await UserTypeController.GetUserTypes();
                    return View();
                }
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: UserType/Create
        public async Task<ActionResult> LogOut()
        {
            Session["UserDetail"] = null;
            return View();
        }

        // GET: UserType/Create
        public async Task<ActionResult> Login()
        {
            Session["UserDetail"] = null;
            return View();
        }


        // POST: UserType/Create
        [HttpPost]
        public async Task<ActionResult> Login(UserDetailModel model)
        {
            //if (!ModelState.IsValid)
            //    return View(model);
            try
            {
                using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
                {
                    string jsonDataModel = JSonFormatter<UserDetailModel>.Serialize(model);

                    HTTPResponseMessage = await httpClientWrap.PostAsyc("API/Users/UserLogin", jsonDataModel);
                }
                if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                {
                    Session["UserDetail"] = model;
                    return RedirectToAction("Administrator", "AdminDashBoard");
                    //  controller = "AdminDashBoard",
                    //            action = "Administrator",
                }
                else
                {
                    model.UserTypeListItems = await UserTypeController.GetUserTypes();
                    return View(model);
                }
            }
            catch (Exception ex)
            {
                return View();
            }
        }


        [HttpGet]
        public async Task<ActionResult> List()
        {
            // API / Users / GetUsers
            List<UserDetailModel> models = null;
            using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                string jsonDataModel = await httpClientWrap.GetStringAsync("API/Users/GetUsers");
                models = JSonFormatter<List<UserDetailModel>>.Deserialize(Convert.ToString(jsonDataModel));
            }
            return View(models);
        }


        // GET: UserType/Create
        public async Task<ActionResult> Create()
        {
            UserDetailModel model = new UserDetailModel();
            model.UserTypeListItems = await UserTypeController.GetUserTypes();
            return View(model);
        }

        // POST: UserType/Create
        [HttpPost]
        public async Task<ActionResult> Create(UserDetailModel model)
        {
            if (!ModelState.IsValid)
                return View(model);
            try
            {
                BaseConveters.CommonConverter(model);
                BaseConveters.CommonConverter(model.PersonalDetail);
                BaseConveters.CommonConverter(model.CommunicationDetail);
                using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
                {
                    string jsonDataModel = JSonFormatter<UserDetailModel>.Serialize(model);

                    HTTPResponseMessage = await httpClientWrap.PostAsyc("API/Users/PostUser", jsonDataModel);
                }
                if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                    return RedirectToAction(ListView);
                else
                {
                    model.UserTypeListItems = await UserTypeController.GetUserTypes();
                    return View(model);
                }
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: UserType/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            UserDetailModel model = null;
            using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                var jsonDataModel = await httpClientWrap.GetStringAsync("API/Users/GetUser/" + id.ToString());
                model = JSonFormatter<UserDetailModel>.Deserialize(Convert.ToString(jsonDataModel));
            }
            model.UserTypeListItems = await UserTypeController.GetUserTypes();
            return View(model);
        }

        // POST: UserType/Edit/5
        [HttpPost]
        public async Task<ActionResult> Edit(UserDetailModel model)
        {
            try
            {
                using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
                {
                    string jsonDataModel = JSonFormatter<UserDetailModel>.Serialize(model);

                    HTTPResponseMessage = await httpClientWrap.PutAsyc("API/Users/PutUser", jsonDataModel);

                }
                if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                    return RedirectToAction("List");
                else
                {
                    model.UserTypeListItems = await UserTypeController.GetUserTypes();
                    return View(model);
                }
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: Users/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Users/Delete/5
        public async Task<ActionResult> Delete(int id)
        {
            using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                HTTPResponseMessage = await httpClientWrap.DeleteAsyc("API/Users/DeleteUser/" + id.ToString());
            }
            if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                return RedirectToAction(ListView);
            else
                return View();
        }

        // POST: Users/Delete/5
        [HttpPost]
        public ActionResult Delete(UserDetailModel userDetail)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
