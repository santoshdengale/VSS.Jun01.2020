﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Mvc;
using VendorSupport.ConvertModelEntity;
using VendorSupport.Formatters;
using VendorSupport.Models;
using VendorSupport.ServicesProxies;

namespace VendorSupport.UX.Controllers
{
    public class CountriesController : BaseController
    {
        public async Task<ActionResult> List()
        {
            // API / Countrys / GetCountrys
            List<CountryDetailModel> models = null;
            using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                string jsonDataModel = await httpClientWrap.GetStringAsync("API/Countrys/GetCountrys");
                models = JSonFormatter<List<CountryDetailModel>>.Deserialize(Convert.ToString(jsonDataModel));
            }
            return View(models);
        }


        // GET: CountryType/Create
        public async Task<ActionResult> Create()
        {
            CountryDetailModel model = new CountryDetailModel();
            //  model.CountryTypeListItems = await CountryTypeController.GetCountryTypes();
            return View(model);
        }

        // POST: CountryType/Create
        [HttpPost]
        public async Task<ActionResult> Create(CountryDetailModel model)
        {
            try
            {
                BaseConveters.CommonConverter(model);
                using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
                {
                    string jsonDataModel = JSonFormatter<CountryDetailModel>.Serialize(model);

                    HTTPResponseMessage = await httpClientWrap.PostAsyc("API/Countrys/PostCountry", jsonDataModel);
                }
                if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                    return RedirectToAction(ListView);
                else
                    return View(model);
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: CountryType/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            CountryDetailModel model = null;
            using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                var jsonDataModel = await httpClientWrap.GetStringAsync("API/Countrys/GetCountry/" + id.ToString());
                model = JSonFormatter<CountryDetailModel>.Deserialize(Convert.ToString(jsonDataModel));
            }
            return View(model);
        }

        // POST: CountryType/Edit/5
        [HttpPost]
        public async Task<ActionResult> Edit(CountryDetailModel model)
        {
            try
            {
                using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
                {
                    string jsonDataModel = JSonFormatter<CountryDetailModel>.Serialize(model);

                    HTTPResponseMessage = await httpClientWrap.PutAsyc("API/Countrys/PutCountry", jsonDataModel);

                }
                if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                    return RedirectToAction("List");
                else
                    return View(model);
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: Countrys/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Countrys/Delete/5
        public async Task<ActionResult> Delete(int id)
        {
            using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                HTTPResponseMessage = await httpClientWrap.DeleteAsyc("API/Countrys/DeleteCountry/" + id.ToString());
            }
            if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                return RedirectToAction(ListView);
            else
                return View();
        }

        // POST: Countrys/Delete/5
        [HttpPost]
        public ActionResult Delete(CountryDetailModel CountryDetail)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
