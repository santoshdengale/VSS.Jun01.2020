﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using System.Web.Mvc;
using VendorSupport.Formatters;
using VendorSupport.Models;
using VendorSupport.ServicesProxies;

namespace VendorSupport.UX.Controllers
{
    public class StatesController : BaseController
    {
        // GET: State/Details/5
        public async Task<ActionResult> List()
        {
            List<StateDetailModel> models = null;
            using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                string jsonString = await httpClientWrap.GetStringAsync("API/States/GetStates");
                models = JSonFormatter<List<StateDetailModel>>.Deserialize(Convert.ToString(jsonString));
            }
            return View(models);
        }

        // GET: State/Details/5
        public ActionResult Read(int id)
        {
            return View();
        }

        // GET: State/Create
        public async Task<ActionResult> Create()
        { 
            ViewBag.Countries =  await CountriesController.GetCountrys();
            return View();
        }

        // POST: State/Create
        [HttpPost]
        public async Task<ActionResult> Create(StateDetailModel model)
        {
            try
            {
                using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
                {
                    string objectTypeJson = JSonFormatter<StateDetailModel>.Serialize(model);
                    HTTPResponseMessage = await httpClientWrap.PostAsyc("API/States/PostState", objectTypeJson);
                }
                if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                    return RedirectToAction("List");
                else
                {
                    ViewBag.Countries = await CountriesController.GetCountrys();
                    return View(model);
                }
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: State/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            StateDetailModel StateDetailM = null;
            using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                var jsonString = await httpClientWrap.GetStringAsync("API/States/GetState/" + id.ToString());
                StateDetailM = JSonFormatter<StateDetailModel>.Deserialize(Convert.ToString(jsonString));

            }
            ViewBag.Countries = await CountriesController.GetCountrys();
            return View(StateDetailM);
        }

        // POST: State/Edit/5
        [HttpPost]
        public async Task<ActionResult> Edit(StateDetailModel model)
        {
            try
            {
                using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
                {
                    string jsonObjectString = JSonFormatter<StateDetailModel>.Serialize(model);
                    HTTPResponseMessage = await httpClientWrap.PutAsyc("API/States/PutState", jsonObjectString);
                }
                if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                    return RedirectToAction("List");
                else
                    return View(model);
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: State/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: State/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public async static Task<List<SelectListItem>> GetStates()
        {
            List<SelectListItem> listItems = new List<SelectListItem>();
            List<StateDetailModel> models = null;
            using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                string jsonString = await httpClientWrap.GetStringAsync("API/States/GetStates");
                models = JSonFormatter<List<StateDetailModel>>.Deserialize(Convert.ToString(jsonString));
            }
            foreach (StateDetailModel model in models)
            {
                SelectListItem selectedItem = new SelectListItem();
                selectedItem.Text = model.Name;
                selectedItem.Value = model.Code.ToString();
                listItems.Add(selectedItem);
            }
            return listItems;
        }
    }
}
