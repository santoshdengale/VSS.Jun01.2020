﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Mvc;
using VendorSupport.ConvertModelEntity;
using VendorSupport.Formatters;
using VendorSupport.Models;
using VendorSupport.ServicesProxies;

namespace VendorSupport.UX.Controllers
{
    public class CitiesController : BaseController
    { 
        public async Task<ActionResult> List()
        {
            // API / Citys / GetCitys
            List<CityDetailModel> models = null;
            using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                string jsonDataModel = await httpClientWrap.GetStringAsync("API/Citys/GetCitys");
                models = JSonFormatter<List<CityDetailModel>>.Deserialize(Convert.ToString(jsonDataModel));
            }
            return View(models);
        }


        // GET: CityType/Create
        public async Task<ActionResult> Create()
        {
         //   CityDetailModel model = new CityDetailModel();
            ViewBag.States = await StatesController.GetStates();
            return View();
        }

        // POST: CityType/Create
        [HttpPost]
        public async Task<ActionResult> Create(CityDetailModel model)
        {

            ViewBag.States = await StatesController.GetStates();
            //if (!ModelState.IsValid)
            //    return View(model);
            try
            {
             
                BaseConveters.CommonConverter(model);
                using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
                {
                    string jsonDataModel = JSonFormatter<CityDetailModel>.Serialize(model);

                    HTTPResponseMessage = await httpClientWrap.PostAsyc("API/Citys/PostCity", jsonDataModel);
                }
                if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                    return RedirectToAction(ListView);
                else
                {
                    if (ViewBag.States==null)
                        ViewBag.States = await StatesController.GetStates();

                    var result=  HTTPResponseMessage.Content.ReadAsStringAsync().Result;

                    return View(model);
                }
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: CityType/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            CityDetailModel model = null;
            using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                var jsonDataModel = await httpClientWrap.GetStringAsync("API/Citys/GetCity/" + id.ToString());
                model = JSonFormatter<CityDetailModel>.Deserialize(Convert.ToString(jsonDataModel));
            }
            return View(model);
        }

        // POST: CityType/Edit/5
        [HttpPost]
        public async Task<ActionResult> Edit(CityDetailModel model)
        {
            try
            {
                using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
                {
                    string jsonDataModel = JSonFormatter<CityDetailModel>.Serialize(model);

                    HTTPResponseMessage = await httpClientWrap.PutAsyc("API/Citys/PutCity", jsonDataModel);

                }
                if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                    return RedirectToAction("List");
                else
                    return View(model);
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: Citys/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Citys/Delete/5
        public async Task<ActionResult> Delete(int id)
        {
            using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                HTTPResponseMessage = await httpClientWrap.DeleteAsyc("API/Citys/DeleteCity/" + id.ToString());
            }
            if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                return RedirectToAction(ListView);
            else
                return View();
        }

        // POST: Citys/Delete/5
        [HttpPost]
        public ActionResult Delete(CityDetailModel CityDetail)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public async static Task<List<SelectListItem>> GetCitys()
        {
            List<SelectListItem> listItems = new List<SelectListItem>();
            List<CityDetailModel> models = null;
            using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                string jsonString = await httpClientWrap.GetStringAsync("API/Citys/GetCitys");
                models = JSonFormatter<List<CityDetailModel>>.Deserialize(Convert.ToString(jsonString));
            }
            foreach (CityDetailModel model in models)
            {
                SelectListItem selectedItem = new SelectListItem();
                selectedItem.Text = model.Name;
                selectedItem.Value = model.Code.ToString();
                listItems.Add(selectedItem);
            }
            return listItems;
        }
    }
}
