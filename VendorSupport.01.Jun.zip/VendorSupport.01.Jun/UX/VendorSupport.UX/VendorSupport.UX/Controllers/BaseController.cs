﻿using System.Configuration;
using System.Net.Http;
using System.Web.Mvc;

namespace VendorSupport.UX.Controllers
{
    public abstract class BaseController : Controller
    {
        protected HttpResponseMessage HTTPResponseMessage { get; set; } 

        protected string vendorServiceBaseURI { get; set; } = string.Empty;
        // vendorServiceBaseURI = ConfigurationManager.AppSettings["VendorServiceBaseURI"];

        protected string ListView { get; set; } = "List";

        public BaseController()
        {
            HTTPResponseMessage = new HttpResponseMessage(System.Net.HttpStatusCode.OK);
            vendorServiceBaseURI = ConfigurationManager.AppSettings["VendorServiceBaseURI"];
        }

        // GET: Base
        public ActionResult Index()
        {
            return View();
        }
    }
}