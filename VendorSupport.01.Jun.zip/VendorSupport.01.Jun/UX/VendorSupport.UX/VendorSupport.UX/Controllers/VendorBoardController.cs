﻿using System;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using System.Web.Mvc;
using VendorSupport.Formatters;
using VendorSupport.Models;
using VendorSupport.ServicesProxies;

namespace VendorSupport.UX.Controllers
{
    public class VendorBoardController : BaseController
    { 
        // GET: Vendor/Details/5
        public async Task<ActionResult> List()
        {
            List<VendorDetailModel> models = null;
            using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                string jsonString = await httpClientWrap.GetStringAsync("API/Vendor/GetVendor");
                models = JSonFormatter<List<VendorDetailModel>>.Deserialize(Convert.ToString(jsonString));
            }
            return View(models);
        }

        // GET: Vendor/Details/5
        public ActionResult Read(int id)
        {
            return View();
        }

        // GET: Vendor/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Vendor/Create
        [HttpPost]
        public async Task<ActionResult> Create(VendorDetailModel model)
        {
            if (!ModelState.IsValid)
                return View(model);
            try
            {
                using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
                {
                    string usrTypeJson = JSonFormatter<VendorDetailModel>.Serialize(model);
                    HTTPResponseMessage = await httpClientWrap.PostAsyc("API/Vendor/PostVendor", usrTypeJson);
                }
                if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                    return RedirectToAction("List");
                else
                    return View(model);
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: Vendor/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            VendorDetailModel VendorDetail = null;
            using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                var jsonString = await httpClientWrap.GetStringAsync("API/Vendor/GetVendor/" + id.ToString());
                VendorDetail = JSonFormatter<VendorDetailModel>.Deserialize(Convert.ToString(jsonString));

            }
            return View(VendorDetail);
        }

        // POST: Vendor/Edit/5
        [HttpPost]
        public async Task<ActionResult> Edit(VendorDetailModel model)
        {
            try
            {
                using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
                {
                    string jsonObjectString = JSonFormatter<VendorDetailModel>.Serialize(model);
                    HTTPResponseMessage = await httpClientWrap.PutAsyc("API/Vendor/PutVendor", jsonObjectString);
                }
                if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                    return RedirectToAction("List");
                else
                    return View(model);
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: Vendor/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Vendor/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public async static Task<List<SelectListItem>> GetVendors()
        {
            List<SelectListItem> listItems = new List<SelectListItem>();
            List<VendorDetailModel> models = null;
            using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                string jsonString = await httpClientWrap.GetStringAsync("API/Vendor/GetVendor");
                models = JSonFormatter<List<VendorDetailModel>>.Deserialize(Convert.ToString(jsonString));
            }
            foreach (VendorDetailModel model in models)
            {
                SelectListItem selectedItem = new SelectListItem();
                selectedItem.Text = model.PersonalDetail.FirstName;
                selectedItem.Value = model.Code.ToString();
                listItems.Add(selectedItem);
            }
            return listItems;
        }
    }
}