﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using System.Web.Mvc;
using VendorSupport.Formatters;
using VendorSupport.Models;
using VendorSupport.ServicesProxies;

namespace VendorSupport.UX.Controllers
{
    public class UserTypeController : BaseController
    {
        // GET: UserType/Details/5
        public async Task<ActionResult> List()
        {
            List<UserTypeDetailModel> userTypes = null;
            using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                string jsonString = await httpClientWrap.GetStringAsync("API/UserTypes/GetUsersType");
                userTypes = JSonFormatter<List<UserTypeDetailModel>>.Deserialize(Convert.ToString(jsonString));
            }
            return View(userTypes);
        }

        // GET: UserType/Details/5
        public ActionResult Read(int id)
        {
            return View();
        }

        // GET: UserType/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: UserType/Create
        [HttpPost]
        public async Task<ActionResult> Create(UserTypeDetailModel model)
        {
            if (!ModelState.IsValid)
                return View(model);
            try
            {

                using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
                {
                    string usrTypeJson = JSonFormatter<UserTypeDetailModel>.Serialize(model);

                    HTTPResponseMessage = await httpClientWrap.PostAsyc("API/UserTypes/PostUserType", usrTypeJson);

                }
                if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                    return RedirectToAction("List");
                else
                    return View(model);
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: UserType/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            UserTypeDetailModel userTypeDetail = null;
            using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {

                var jsonString = await httpClientWrap.GetStringAsync("API/UserTypes/GetUserType/" + id.ToString());
                userTypeDetail = JSonFormatter<UserTypeDetailModel>.Deserialize(Convert.ToString(jsonString));

            }
            return View(userTypeDetail);
        }

        // POST: UserType/Edit/5
        [HttpPost]
        public async Task<ActionResult> Edit(UserTypeDetailModel userTypeDetail)
        {

            try
            {

                using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
                {
                    string usrTypeJson = JSonFormatter<UserTypeDetailModel>.Serialize(userTypeDetail);

                    HTTPResponseMessage = await httpClientWrap.PutAsyc("API/UserTypes/PutUserType", usrTypeJson);

                }
                if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                    return RedirectToAction("List");
                else
                    return View(userTypeDetail);
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: UserType/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: UserType/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public async static Task<List<SelectListItem>> GetUserTypes()
        {
            List<SelectListItem> listItems = new List<SelectListItem>();
            List<UserTypeDetailModel> models = null;
            using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                string jsonString = await httpClientWrap.GetStringAsync("API/UserTypes/GetUsersType");
                models = JSonFormatter<List<UserTypeDetailModel>>.Deserialize(Convert.ToString(jsonString));
            }
            foreach (UserTypeDetailModel model in models)
            {
                SelectListItem selectedItem = new SelectListItem();
                selectedItem.Text = model.UserTypeName;
                selectedItem.Value = model.UserTypeCode.ToString();
                listItems.Add(selectedItem);
            }
            return listItems;
        }
    }
}
