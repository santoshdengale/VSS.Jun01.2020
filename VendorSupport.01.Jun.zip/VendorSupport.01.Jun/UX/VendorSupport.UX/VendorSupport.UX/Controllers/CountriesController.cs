﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using System.Web.Mvc;
using VendorSupport.Formatters;
using VendorSupport.Models;
using VendorSupport.ServicesProxies;

namespace VendorSupport.UX.Controllers
{
    public class CountriesController : BaseController
    {
        // GET: Country/Details/5
        public async Task<ActionResult> List()
        {
            List<CountryDetailModel> models = null;
            using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                string jsonString = await httpClientWrap.GetStringAsync("API/Countries/GetCountries");
                models = JSonFormatter<List<CountryDetailModel>>.Deserialize(Convert.ToString(jsonString));
            }
            return View(models);
        }

        // GET: Country/Details/5
        public ActionResult Read(int id)
        {
            return View();
        }

        // GET: Country/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Country/Create
        [HttpPost]
        public async Task<ActionResult> Create(CountryDetailModel model)
        {
            if (!ModelState.IsValid)
                return View(model);
            try
            { 
                using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
                {
                    string usrTypeJson = JSonFormatter<CountryDetailModel>.Serialize(model); 
                    HTTPResponseMessage = await httpClientWrap.PostAsyc("API/Countries/PostCountry", usrTypeJson); 
                }
                if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                    return RedirectToAction("List");
                else
                    return View(model);
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: Country/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            CountryDetailModel CountryDetail = null;
            using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
            { 
                var jsonString = await httpClientWrap.GetStringAsync("API/Countries/GetCountry/" + id.ToString());
                CountryDetail = JSonFormatter<CountryDetailModel>.Deserialize(Convert.ToString(jsonString));

            }
            return View(CountryDetail);
        }

        // POST: Country/Edit/5
        [HttpPost]
        public async Task<ActionResult> Edit(CountryDetailModel model)
        { 
            try
            { 
                using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
                {
                    string jsonObjectString = JSonFormatter<CountryDetailModel>.Serialize(model); 
                    HTTPResponseMessage = await httpClientWrap.PutAsyc("API/Countries/PutCountry", jsonObjectString);
                }
                if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                    return RedirectToAction("List");
                else
                    return View(model);
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: Country/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Country/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public async static Task<List<SelectListItem>> GetCountrys()
        {
            List<SelectListItem> listItems = new List<SelectListItem>();
            List<CountryDetailModel> models = null;
            using (HttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                string jsonString = await httpClientWrap.GetStringAsync("API/Countries/GetCountries");
                models = JSonFormatter<List<CountryDetailModel>>.Deserialize(Convert.ToString(jsonString));
            }
            foreach (CountryDetailModel model in models)
            {
                SelectListItem selectedItem = new SelectListItem();
                selectedItem.Text = model.Name;
                selectedItem.Value = model.Code.ToString();
                listItems.Add(selectedItem);
            }
            return listItems;
        }
    }
}
