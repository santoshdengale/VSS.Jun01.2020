﻿using System.Web.Mvc;
using VendorSupport.Common;

namespace VendorSupport.UX.Controllers
{
    public class PartialViewsController : BaseController
    {
        // GET: PartialViews
        public PartialViewResult HeaderView()
        {
             ViewBag.Title =  StringConstants.APPLOCATION_TITLE;
             return PartialView();
        }

        // GET: PartialViews
        public PartialViewResult FooterView()
        {
            return PartialView();
        }


        // GET: PartialViews
        public PartialViewResult LHSView()
        {
            return PartialView();
        }



        // GET: PartialViews
        public PartialViewResult RHSView()
        {
            return PartialView();
        }


        #region Admin Pages
        // GET: PartialViews
        public PartialViewResult LHSAdminView()
        {
            return PartialView();
        }


        // GET: PartialViews
        public PartialViewResult HeaderAdminView()
        {
            ViewBag.Title = StringConstants.APPLOCATION_TITLE;
            return PartialView();
        }

        // GET: PartialViews
        public PartialViewResult FooterAdminView()
        {
            ViewBag.Title = StringConstants.APPLOCATION_TITLE;
            return PartialView();
        }

        #endregion Admin Pages
    }
}