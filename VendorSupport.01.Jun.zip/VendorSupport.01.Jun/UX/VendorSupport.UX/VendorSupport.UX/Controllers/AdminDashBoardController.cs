﻿using System.Web.Mvc;

namespace VendorSupport.UX.Controllers
{
    public class AdminDashBoardController : BaseController
    {
        // GET: AdminDashBoard
        public ActionResult AdminDashBoardView()
        {
            return View();
        }

        public ActionResult Administrator()
        {
            return View();
        }
    }
}