﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Mvc;
using VendorSupport.ConvertModelEntity;
using VendorSupport.Formatters;
using VendorSupport.Models;
using VendorSupport.ServicesProxies;

namespace VendorSupport.UX.Controllers
{
    public class AreasController : BaseController
    {
        public async Task<ActionResult> List()
        {
            // API / Areas / GetAreas
            List<AreaDetailModel> models = null;
            using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                string jsonDataModel = await httpClientWrap.GetStringAsync("API/Areas/GetAreas");
                models = JSonFormatter<List<AreaDetailModel>>.Deserialize(Convert.ToString(jsonDataModel));
            }
            return View(models);
        }


        // GET: AreaType/Create
        public async Task<ActionResult> Create()
        {
            AreaDetailModel model = new AreaDetailModel();
            ViewBag.Cities = await CitiesController.GetCitys();
            return View();
        }

        // POST: AreaType/Create
        [HttpPost]
        public async Task<ActionResult> Create(AreaDetailModel model)
        {
            try
            {
                //if (!ModelState.IsValid)
                //    return View(model);

                ViewBag.Cities = await CitiesController.GetCitys();

                BaseConveters.CommonConverter(model);
                using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
                {
                    string jsonDataModel = JSonFormatter<AreaDetailModel>.Serialize(model);

                    HTTPResponseMessage = await httpClientWrap.PostAsyc("API/Areas/PostArea", jsonDataModel);
                }
                if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                    return RedirectToAction(ListView);
                else
                {
                    if (ViewBag.Cities == null)
                        ViewBag.Cities = await CitiesController.GetCitys();
                    return View(model);
                }
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: AreaType/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            AreaDetailModel model = null;
            using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                var jsonDataModel = await httpClientWrap.GetStringAsync("API/Areas/GetArea/" + id.ToString());
                model = JSonFormatter<AreaDetailModel>.Deserialize(Convert.ToString(jsonDataModel));
            }
            return View(model);
        }

        // POST: AreaType/Edit/5
        [HttpPost]
        public async Task<ActionResult> Edit(AreaDetailModel model)
        {
            try
            {
                using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
                {
                    string jsonDataModel = JSonFormatter<AreaDetailModel>.Serialize(model);

                    HTTPResponseMessage = await httpClientWrap.PutAsyc("API/Areas/PutArea", jsonDataModel);

                }
                if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                    return RedirectToAction("List");
                else
                {
                    if (ViewBag.Cities == null)
                        ViewBag.Cities = await CitiesController.GetCitys();
                    return View(model);
                }
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: Areas/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Areas/Delete/5
        public async Task<ActionResult> Delete(int id)
        {
            using (IHttpClientWrapper httpClientWrap = new HttpClientWrapper())
            {
                HTTPResponseMessage = await httpClientWrap.DeleteAsyc("API/Areas/DeleteArea/" + id.ToString());
            }
            if (HTTPResponseMessage.StatusCode == HttpStatusCode.OK)
                return RedirectToAction(ListView);
            else
                return View();
        }

        // POST: Areas/Delete/5
        [HttpPost]
        public ActionResult Delete(AreaDetailModel AreaDetail)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
