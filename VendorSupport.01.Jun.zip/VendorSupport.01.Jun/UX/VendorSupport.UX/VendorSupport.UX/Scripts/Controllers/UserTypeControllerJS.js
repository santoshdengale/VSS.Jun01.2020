﻿$(document).ready(
    function () {
        console.log("Controller JS Ready!");
        //alert("Controller JS Ready!");
    });

