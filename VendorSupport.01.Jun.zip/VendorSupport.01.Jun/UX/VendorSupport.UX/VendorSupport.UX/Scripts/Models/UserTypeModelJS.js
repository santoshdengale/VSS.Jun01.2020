﻿$(document).ready(
    function () {
        console.log("Model JS Ready!");
       // alert("Model JS Ready!");
    });