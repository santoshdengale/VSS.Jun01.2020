﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VendorSupport.UX.APICall
{
    public static class APIClient
    {
        static APIClient()
        { 
        
        }
    }
}