﻿using System.Web;
using System.Web.Optimization;

namespace VendorSupport.UX
{
    public class BundleConfig
    {
        // For more information on bundling, visit https://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {

            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.validate*"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at https://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                      "~/Scripts/bootstrap.js"));

            #region Scripts Controllers
            bundles.Add(new ScriptBundle("~/bundles/Controllers").Include( 
                   "~/Scripts/Controllers/UserTypeControllerJS.js"));

            #endregion Scripts Controllers

            #region Scripts Models
            bundles.Add(new ScriptBundle("~/bundles/Models").Include(
                  "~/Scripts/Models/UserTypeModelJS.js"));
            #endregion Scripts Models

            #region Third Party Scripts Bundling
            bundles.Add(new ScriptBundle("~/bundles/JQueryUI").Include(
                  "~/Scripts/jquery-ui-1.12.1.js",
                  "~/Scripts/jquery-ui-1.12.1.min.js"));
            #endregion Third Party Scripts Bundling



            bundles.Add(new StyleBundle("~/Content/css").Include(
                      "~/Content/bootstrap.css",
                      "~/Content/site.css"));

            //https://zoompf.com/blog/2015/01/automatically-optimize-css-javascript-asp-net/
            bundles.Add(new StyleBundle("~/Content/css").Include(
                      "~/Content/bootstrap.css",
                      "~/Content/site.css"));

            #region Custom CSS
            bundles.Add(new StyleBundle("~/Content/CustomCSS").Include(
                   "~/Content/CustomCSS/CSSCustomStyles.css",
                    "~/Content/CustomCSS/CSSMainPage.css"));
            #endregion Custom CSS


            //BundleTable.EnableOptimizations = true;
        }
    }
}
