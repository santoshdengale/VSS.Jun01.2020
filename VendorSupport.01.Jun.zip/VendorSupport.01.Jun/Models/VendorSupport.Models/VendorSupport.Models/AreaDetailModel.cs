﻿using System.ComponentModel.DataAnnotations;
using VendorSupport.Common;

namespace VendorSupport.Models
{
    public class AreaDetailModel : BaseModel
    {
        [Required]
        [Display(Name = "Code")]
        public decimal Code { get; set; } // Code (Primary key)

        [Required(ErrorMessage = ValidationMessages.INPUT_VALIDATE_NAME)]
        [MaxLength(100)]
        [StringLength(100)]
        [Display(Name = "Name")]
        public string Name { get; set; } // Name (length: 100)

         [Display(Name = "City Name")]
        [Required(ErrorMessage = ValidationMessages.INPUT_VALIDATE_NAME)]
        public string CityCode { get; set; } // CityCode

        /// <summary>
        /// Parent CityDetail pointed by [AreaDetail].([CityCode]) (FK_AreaDetail_CityDetail)
        /// </summary>
        public virtual CityDetailModel CityDetail { get; set; } // FK_AreaDetail_CityDetail


        public AreaDetailModel()
        {
            CityDetail = new CityDetailModel();
        }
    }

}
// </auto-generated>
