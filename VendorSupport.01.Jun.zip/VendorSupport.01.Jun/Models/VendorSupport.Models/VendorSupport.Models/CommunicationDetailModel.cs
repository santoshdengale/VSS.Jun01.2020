﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendorSupport.Models
{
    public class CommunicationDetailModel : BaseModel
    {
        [Display(Name = "Code")]
        public decimal Code { get; set; } // Code (Primary key)

        [MaxLength(500)]
        [StringLength(500)]
        [Display(Name = "Address 1")]
        public string Address1 { get; set; } // Address1 (length: 500)

        [MaxLength(500)]
        [StringLength(500)]
        [Display(Name = "Address 2")]
        public string Address2 { get; set; } // Address2 (length: 500)

        [MaxLength(500)]
        [StringLength(500)]
        [Display(Name = "Area 1")]
        public string Area1 { get; set; } // Area1 (length: 500)

        [MaxLength(500)]
        [StringLength(500)]
        [Display(Name = "Area 2")]
        public string Area2 { get; set; } // Area2 (length: 500)

        [MaxLength(500)]
        [StringLength(500)]
        [Display(Name = "Nearest land mark")]
        public string NearestLandMark { get; set; } // NearestLandMark (length: 500)

        [MaxLength(25)]
        [StringLength(25)]
        [Display(Name = "Mobile 1")]
        public string Mobile1 { get; set; } // Mobile1 (length: 25)

        [MaxLength(25)]
        [StringLength(25)]
        [Display(Name = "Mobile 2")]
        public string Mobile2 { get; set; } // Mobile2 (length: 25)

        [Display(Name = "Communication type")]
        public int? CommunicationType { get; set; } // CommunicationType

        [MaxLength(50)]
        [StringLength(50)]
        [Display(Name = "Email 1")]
        [EmailAddress(ErrorMessage = "Invalid Email Address.")]
        public string Email1 { get; set; } // Email1 (length: 25)

        [MaxLength(25)]
        [StringLength(25)]
        [Display(Name = "Pin code")]
        public string PinCode { get; set; } // PinCode (length: 25)



        // Reverse navigation

        /// <summary>
        /// Child UserDetails where [UserDetail].[CommCode] point to this entity (FK_UserDetail_CommunicationDetail)
        /// </summary>
        public virtual System.Collections.Generic.ICollection<UserDetailModel> UserDetails { get; set; } // UserDetail.FK_UserDetail_CommunicationDetail
        /// <summary>
        /// Child VendorDetails where [VendorDetail].[CommCode] point to this entity (FK_VendorDetail_CommunicationDetail)
        /// </summary>
        public virtual System.Collections.Generic.ICollection<VendorDetailModel> VendorDetails { get; set; } // VendorDetail.FK_VendorDetail_CommunicationDetail

        public CommunicationDetailModel()
        {
            CommunicationType = (int)Common.EnumCommunicationType.Residiential;
            UserDetails = new System.Collections.Generic.List<UserDetailModel>();
            VendorDetails = new System.Collections.Generic.List<VendorDetailModel>();
        }
    }

}