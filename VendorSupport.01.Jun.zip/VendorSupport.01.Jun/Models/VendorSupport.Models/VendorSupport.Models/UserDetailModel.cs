﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using VendorSupport.Common;
using VendorSupport.Extensions;

namespace VendorSupport.Models
{
    public class UserDetailModel : BaseModel
    {
        [Required]
        [Display(Name = "Code")]
        public decimal Code { get; set; } // Code (Primary key)

        [Required(ErrorMessage = ValidationMessages.INPUT_VALIDATE_NAME)]
        [MaxLength(50)]
        [StringLength(50)]
        [Display(Name = "User Name")]
        public string Name { get; set; } // Name (length: 50)

        //[Required(AllowEmptyStrings = true)]
        //[MaxLength(50)]
        //[StringLength(50)]
        //[Display(Name = "Up assword")]
        //public string UPassword { get; set; } // UPassword (length: 50)

        [Required(ErrorMessage = ValidationMessages.INPUT_VALIDATE_NAME)]
        [MaxLength(50)]
        [StringLength(50)]
        [Display(Name = "Password")]
        public string UPassword { get; set; } // UPassword (length: 50)


        [Required(ErrorMessage = ValidationMessages.INPUT_VALIDATE_NAME)]
        [System.ComponentModel.DataAnnotations.Compare("UPassword",
            ErrorMessage = ValidationMessages.INPUT_VALIDATE_CONFIRMED_PASSWORD)]
        [MaxLength(50)]
        [StringLength(50)]
        [Display(Name = "Confirmed Password")]
        public string UCofirmPassword { get; set; } // UPassword (length: 50)

        [Display(Name = "User type code")]
        [Required(ErrorMessage = ValidationMessages.INPUT_VALIDATE_NAME)]
        public string UserTypeCode { get; set; } // UserTypeCode

        [Display(Name = "Comm code")]
        public decimal? CommCode { get; set; } // CommCode

        [Display(Name = "Personal code")]
        public decimal? PersonalCode { get; set; } // PersonalCode

        public List<SelectListItem> UserTypeListItems { get; set; }

        // Reverse navigation

        /// <summary>
        /// Child VendorDetails where [VendorDetail].[UserCode] point to this entity (FK_VendorDetail_UserDetail)
        /// </summary>
        public virtual System.Collections.Generic.ICollection<VendorDetailModel> VendorDetails { get; set; } // VendorDetail.FK_VendorDetail_UserDetail

        // Foreign keys

        /// <summary>
        /// Parent CommunicationDetail pointed by [UserDetail].([CommCode]) (FK_UserDetail_CommunicationDetail)
        /// </summary>
        public virtual CommunicationDetailModel CommunicationDetail { get; set; } // FK_UserDetail_CommunicationDetail

        /// <summary>
        /// Parent PersonalDetail pointed by [UserDetail].([PersonalCode]) (FK_UserDetail_PersonalDetail)
        /// </summary>
        public virtual PersonalDetailModel PersonalDetail { get; set; } // FK_UserDetail_PersonalDetail

        /// <summary>
        /// Parent UserTypeDetail pointed by [UserDetail].([UserTypeCode]) (FK_UserDetail_UserTypeDetail)
        /// </summary>
        public virtual UserTypeDetailModel UserTypeDetail { get; set; } // FK_UserDetail_UserTypeDetail

        public UserDetailModel()
        {
            VendorDetails = new System.Collections.Generic.List<VendorDetailModel>();
            CommunicationDetail = new CommunicationDetailModel();
            PersonalDetail = new PersonalDetailModel();
            UserTypeDetail = new UserTypeDetailModel();
            UserTypeListItems = new List<SelectListItem>();
            UserTypeCode = "1"; // Convert.ToString( UserTypeCode.ValidateUserType());
        }
    }

}
// </auto-generated>
