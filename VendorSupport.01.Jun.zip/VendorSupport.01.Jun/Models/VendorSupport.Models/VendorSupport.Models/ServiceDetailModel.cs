﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using VendorSupport.Common;

namespace VendorSupport.Models
{
    public class ServiceDetailModel : BaseModel
    {
           [Display(Name = "Code")]
        public decimal Code { get; set; } // Code (Primary key)

        [Required(ErrorMessage = ValidationMessages.INPUT_VALIDATE_NAME)]
        [MaxLength(100)]
        [StringLength(100)]
        [Display(Name = "Name")]
        public string Name { get; set; } // Name (length: 100) 
    }
}
