﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendorSupport.Models
{
    public class PartialViewModel
    {
        public string Header { get; set; } // Address1 (length: 250)

       
        public string Footer { get; set; } // Address2 (length: 250)

      
        public string Name { get; set; } // Mobile1 (length: 25)

    }
}
