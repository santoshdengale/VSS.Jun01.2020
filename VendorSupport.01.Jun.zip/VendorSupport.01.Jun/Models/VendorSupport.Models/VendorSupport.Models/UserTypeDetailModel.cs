﻿using System.ComponentModel.DataAnnotations;
using VendorSupport.Common;
using VendorSupport.Extensions;

namespace VendorSupport.Models
{
    public class UserTypeDetailModel : BaseModel
    {
        [Required]
        [Display(Name = "User type code")]
        public decimal UserTypeCode { get; set; } // UserTypeCode (Primary key)

        [MaxLength(150)]
        [StringLength(150)]
        [Display(Name = "User type name")]
        [Required(ErrorMessage = ValidationMessages.INPUT_VALIDATE_NAME)]
        public string UserTypeName { get; set; } // UserTypeName (length: 150)


        [Display(Name = "User code")]
        public decimal? UserCode { get; set; } // UserCode

        // Reverse navigation

        /// <summary>
        /// Child UserDetails where [UserDetail].[UserTypeCode] point to this entity (FK_UserDetail_UserTypeDetail)
        /// </summary>
        public virtual System.Collections.Generic.ICollection<UserDetailModel> UserDetails { get; set; } // UserDetail.FK_UserDetail_UserTypeDetail

        public UserTypeDetailModel()
        {
            UserDetails = new System.Collections.Generic.List<UserDetailModel>();
            UserTypeCode = UserTypeCode.ValidateUserType();
        }
    }

}
// </auto-generated>
