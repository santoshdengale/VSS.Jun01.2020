﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.ComponentModel.DataAnnotations;
using VendorSupport.Common;

namespace VendorSupport.Models
{
    public class CityDetailModel : BaseModel
    {
        [Required]
        [Display(Name = "Code")]
        public decimal Code { get; set; } // Code (Primary key)

        [Required(ErrorMessage = ValidationMessages.INPUT_VALIDATE_NAME)]
        [MaxLength(100)]
        [StringLength(100)]
        [Display(Name = "Name")]
        public string Name { get; set; } // Name (length: 100)

        [Display(Name = "State code")]
        [Required(ErrorMessage = ValidationMessages.INPUT_VALIDATE_NAME)]
        public string StateCode { get; set; } // StateCode

        /// <summary>
        /// Child AreaDetails where [AreaDetail].[CityCode] point to this entity (FK_AreaDetail_CityDetail)
        /// </summary>
        public virtual System.Collections.Generic.ICollection<AreaDetailModel> AreaDetails { get; set; } // AreaDetail.FK_AreaDetail_CityDetail

        // Foreign keys

        /// <summary>
        /// Parent StateDetail pointed by [CityDetail].([StateCode]) (FK_CityDetail_StateDetail)
        /// </summary>
        public virtual StateDetailModel StateDetail { get; set; } // FK_CityDetail_StateDetail


        public CityDetailModel()
        {
            StateDetail = new StateDetailModel();
            AreaDetails = new System.Collections.Generic.List<AreaDetailModel>();
        }
    }

}
// </auto-generated>
