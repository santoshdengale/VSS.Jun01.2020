﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using VendorSupport.Common;

namespace VendorSupport.Models
{
    public class CountryDetailModel : BaseModel
    {
        [Display(Name = "Code")]
        public decimal Code { get; set; } // Code (Primary key)


        [Required(ErrorMessage = ValidationMessages.INPUT_VALIDATE_NAME)]
        [Display(Name = "Name")]
        public string Name { get; set; } // Name (length: 100)


        // Reverse navigation 
        /// <summary>
        /// Child StateDetails where [StateDetail].[CountryCode] point to this entity (FK_StateDetail_CountryDetail)
        /// </summary>
        public virtual System.Collections.Generic.ICollection<StateDetailModel> StateDetails { get; set; } // StateDetail.FK_StateDetail_CountryDetail

        public CountryDetailModel()
        {
            StateDetails = new System.Collections.Generic.List<StateDetailModel>();
        }
    }
}
