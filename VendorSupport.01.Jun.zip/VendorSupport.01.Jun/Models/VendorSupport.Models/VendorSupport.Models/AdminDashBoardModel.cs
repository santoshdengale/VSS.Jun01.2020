﻿using System.ComponentModel.DataAnnotations;

namespace VendorSupport.Models
{
    public class AdminDashBoardModel
    {
        [Display(Name = "Header")]
        public string HeaderName { get; set; }

        [Display(Name = "Content name")]
        public string Content { get; set; }
    }
}
