﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendorSupport.Common;
using VendorSupport.Extensions;

namespace VendorSupport.Models
{
    public class PersonalDetailModel : BaseModel
    {
        [Required]
        [Display(Name = "Code")]
        public decimal Code { get; set; } // Code (Primary key)

        [Required(ErrorMessage = ValidationMessages.INPUT_VALIDATE_NAME)]
        [MaxLength(50)]
        [StringLength(50)]
        [Display(Name = "First name")]
        public string FirstName { get; set; } // FirstName (length: 50)

        [MaxLength(50)]
        [StringLength(50)]
        [Display(Name = "Middle name")]
        public string MiddleName { get; set; } // MiddleName (length: 50)

        [Required(ErrorMessage = ValidationMessages.INPUT_VALIDATE_NAME)]
        [MaxLength(50)]
        [StringLength(50)]
        [Display(Name = "Last name")]
        public string LastName { get; set; } // LastName (length: 50)

        [MaxLength(10)]
        [StringLength(10)]
        [Display(Name = "Sex")]
        public string Sex { get; set; } // SEX (length: 10)

        [DataType(DataType.DateTime)]
        [Display(Name = "Date of birth")]
        public System.DateTime? DateOfBirth { get; set; } // DateOfBirth

        // Reverse navigation

        /// <summary>
        /// Child UserDetails where [UserDetail].[PersonalCode] point to this entity (FK_UserDetail_PersonalDetail)
        /// </summary>
        public virtual System.Collections.Generic.ICollection<UserDetailModel> UserDetails { get; set; } // UserDetail.FK_UserDetail_PersonalDetail
       
        /// <summary>
        /// Child VendorDetails where [VendorDetail].[PersonalCode] point to this entity (FK_VendorDetail_PersonalDetail)
        /// </summary>
        public virtual System.Collections.Generic.ICollection<VendorDetailModel> VendorDetails { get; set; } // VendorDetail.FK_VendorDetail_PersonalDetail

        public PersonalDetailModel()
        {
            if (DateOfBirth == null)
                DateOfBirth = DateTime.Now;
            else
                DateOfBirth = DateOfBirth.Value.ValidateDate();

            //Sex = Common.EnumSex.Male.ToString();
            UserDetails = new System.Collections.Generic.List<UserDetailModel>();
            VendorDetails = new System.Collections.Generic.List<VendorDetailModel>();
        }
    }

}
// </auto-generated>
