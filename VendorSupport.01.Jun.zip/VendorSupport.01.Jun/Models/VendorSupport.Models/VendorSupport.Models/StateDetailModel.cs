﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using Newtonsoft.Json;
using VendorSupport.Common;

namespace VendorSupport.Models
{
    public class StateDetailModel : BaseModel
    {
        [Required]
        [Display(Name = "Code")]
        public decimal Code { get; set; } // Code (Primary key)

        [Required(ErrorMessage = ValidationMessages.INPUT_VALIDATE_NAME)]
        [MaxLength(100)]
        [StringLength(100)]
        [Display(Name = "Name")]
        public string Name { get; set; } // Name (length: 100)

        [Display(Name = "Country code")]
        [Required(ErrorMessage = ValidationMessages.INPUT_VALIDATE_NAME)]
        public string CountryCode { get; set; } // CountryCode


        // Reverse navigation

        /// <summary>
        /// Child CityDetails where [CityDetail].[StateCode] point to this entity (FK_CityDetail_StateDetail)
        /// </summary>
        public virtual System.Collections.Generic.ICollection<CityDetailModel> CityDetails { get; set; } // CityDetail.FK_CityDetail_StateDetail
        /// <summary>
        /// Child DistrictDetails where [DistrictDetail].[StateCode] point to this entity (FK_DistrictDetail_StateDetail)
        /// </summary>
        public virtual System.Collections.Generic.ICollection<DistrictDetailModel> DistrictDetails { get; set; } // DistrictDetail.FK_DistrictDetail_StateDetail

        // Foreign keys

        /// <summary>
        /// Parent CountryDetail pointed by [StateDetail].([CountryCode]) (FK_StateDetail_CountryDetail)
        /// </summary>
        public virtual CountryDetailModel CountryDetail { get; set; } // FK_StateDetail_CountryDetail
         
        public StateDetailModel()
        {
            CityDetails = new System.Collections.Generic.List<CityDetailModel>();
            DistrictDetails = new System.Collections.Generic.List<DistrictDetailModel>();
            CountryDetail = new CountryDetailModel();
        }
    }
}

