﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using VendorSupport.Extensions;

namespace VendorSupport.Models
{
   public class VendorDetailModel : BaseModel
    {
          [Display(Name = "Code")]
        public decimal Code { get; set; } // Code (Primary key)

        [Display(Name = "Personal code")]
        public decimal? PersonalCode { get; set; } // PersonalCode

        [Display(Name = "Comm code")]
        public decimal? CommCode { get; set; } // CommCode

        [Display(Name = "User audit code")]

        public decimal? UserAuditCode { get; set; } // UserAuditCode

        // Foreign keys

        /// <summary>
        /// Parent CommunicationDetail pointed by [VendorDetail].([CommCode]) (FK_VendorDetail_CommunicationDetail)
        /// </summary>
        public virtual CommunicationDetailModel CommunicationDetail { get; set; } // FK_VendorDetail_CommunicationDetail

        /// <summary>
        /// Parent PersonalDetail pointed by [VendorDetail].([PersonalCode]) (FK_VendorDetail_PersonalDetail)
        /// </summary>
        public virtual PersonalDetailModel PersonalDetail { get; set; } // FK_VendorDetail_PersonalDetail

        /// <summary>
        /// Parent UserDetail pointed by [VendorDetail].([UserCode]) (FK_VendorDetail_UserDetail)
        /// </summary>
        public virtual UserDetailModel UserDetail { get; set; } // FK_VendorDetail_UserDetail

        public VendorDetailModel()
        {
            CommunicationDetail = new CommunicationDetailModel();
            PersonalDetail = new PersonalDetailModel();
            UserDetail = new UserDetailModel();
            UserAuditCode = UserAuditCode.ValidateUser();
        }
    }

}
// </auto-generated>