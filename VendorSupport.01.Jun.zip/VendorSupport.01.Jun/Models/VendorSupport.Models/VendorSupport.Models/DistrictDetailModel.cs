﻿using System.ComponentModel.DataAnnotations;
using VendorSupport.Common;

namespace VendorSupport.Models
{
    public class DistrictDetailModel :BaseModel
    { 
        [Display(Name = "Code")]
        public decimal Code { get; set; } // Code (Primary key)
         
        [Display(Name = "Name")]
        [Required(ErrorMessage = ValidationMessages.INPUT_VALIDATE_NAME)]
        public string Name { get; set; } // Name (length: 100)

        [Display(Name = "State code")]
        [Required(ErrorMessage = ValidationMessages.INPUT_VALIDATE_NAME)]
        public decimal? StateCode { get; set; } // StateCode

        /// <summary>
        /// Parent StateDetail pointed by [DistrictDetail].([StateCode]) (FK_DistrictDetail_StateDetail)
        /// </summary>
        public virtual StateDetailModel StateDetail { get; set; } // FK_DistrictDetail_StateDetail

        public DistrictDetailModel()
        {
            StateDetail = new StateDetailModel();
        } 
    } 
}