﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendorSupport.Extensions;

namespace VendorSupport.Models
{
    public abstract class BaseModel
    {
        [Display(Name = "User code")]
        public decimal? UserCode { get; set; } // UserCode 

        [Required]
        [MaxLength(8)]
        [Display(Name = "Row version")]
        public byte[] RowVersion { get; set; } // RowVersion (length: 8)

        [Display(Name = "Create by")]
        public decimal? CreateBy { get; set; } // CreateBy

        [DataType(DataType.DateTime)]
        [Display(Name = "Created date")]
        public System.DateTime? CreatedDate { get; set; } // CreatedDate

        [Display(Name = "Modified by")]
        public decimal? ModifiedBy { get; set; } // ModifiedBy

        [DataType(DataType.DateTime)]
        [Display(Name = "Modified date")]
        public System.DateTime? ModifiedDate { get; set; } // ModifiedDate

        public BaseModel()
        {
            CreatedDate = DateTime.Now; // CreatedDate.Value.ValidateDate();
            ModifiedDate = DateTime.Now; ModifiedDate.Value.ValidateDate();
            CreateBy = CreateBy.ValidateUser();
            ModifiedBy = ModifiedBy.ValidateUser();
        }

    }
}
