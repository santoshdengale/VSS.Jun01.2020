﻿using AutoMapper;
using System;


namespace VendorSupport.Utilities
{
    public static class AutoMapperUtility<S, D> //where T,  U : class  
    {
        public static D Mapper(S s)
        {
            D result = default(D);
            try
            {
                MapperConfiguration configuration = new MapperConfiguration(
                  cfg => cfg.CreateMap<S, D>());
                Mapper mapper = new Mapper(configuration);
                result = mapper.Map<S, D>(s);
            }
            catch (Exception ex)
            {
            }
            return result;

        }
    }
}
