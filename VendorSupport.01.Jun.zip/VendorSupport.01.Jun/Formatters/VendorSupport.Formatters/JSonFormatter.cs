﻿using Newtonsoft.Json;
using System.Runtime.Serialization.Formatters;

namespace VendorSupport.Formatters
{
    public static class JSonFormatter<T>
    {
        public static T Deserialize(string jsonString)
        {
            JsonSerializerSettings jSerializerSettings = new JsonSerializerSettings();
            jSerializerSettings.Formatting = Formatting.Indented;
            T t = default(T); 
            t = JsonConvert.DeserializeObject<T>(jsonString); 
            return t;
        }

        public static string Serialize(T t)
        {
            string jsonString  = JsonConvert.SerializeObject(t,
                  Formatting.Indented, new JsonSerializerSettings
                  {
                      NullValueHandling = NullValueHandling.Include,
                      TypeNameHandling = TypeNameHandling.All,
                      TypeNameAssemblyFormat = FormatterAssemblyStyle.Simple
                  });
            return jsonString;
        }
    }
}
