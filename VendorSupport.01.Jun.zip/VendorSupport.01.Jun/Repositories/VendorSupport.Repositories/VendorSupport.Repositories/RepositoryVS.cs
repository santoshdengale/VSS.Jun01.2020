﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.DataBaseContext;

namespace VendorSupport.Repositories
{
    public class RepositoryVS<T> : BaseRepository<T>, IDisposable, IRepositoryVS<T> where T : class
    {
        private readonly IDataBaseContextVS<T> dataBaseContext;
        public RepositoryVS()
        {
            dataBaseContext = new DataBaseContextVS<T>();
        }

        public async Task<T> Create(T t)
        {
            return await dataBaseContext.Create(t);
        }

        public async Task<bool> Delete(T t)
        {
            return await dataBaseContext.Delete(t);
        }

        public async Task<IQueryable<T>> Read(T t)
        {
            return await dataBaseContext.Read(t);
        }

        public async Task<IQueryable<T>> Read()
        {
            return await dataBaseContext.Read();
        }


        public async Task<T> Upsert(T t)
        {
            try
            {
                return await dataBaseContext.Upsert(t);
            }
            catch (Exception ex)
            {
                var res = ex;
                throw;
            }
           
        }


        

        #region IDisposable Pattern
        // Flag: Has Dispose already been called?
        bool disposed = false;
        // Instantiate a SafeHandle instance.


        // Public implementation of Dispose pattern callable by consumers.
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        // Protected implementation of Dispose pattern.
        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
                ((DataBaseContextVS<T>)dataBaseContext).Dispose();

            disposed = true;
        } 
        #endregion IDisposable Pattern
    }
}
