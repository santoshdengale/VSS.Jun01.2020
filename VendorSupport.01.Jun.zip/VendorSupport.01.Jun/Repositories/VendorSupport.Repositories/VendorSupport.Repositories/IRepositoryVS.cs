﻿using System.Linq;
using System.Threading.Tasks;

namespace VendorSupport.Repositories
{
    public interface IRepositoryVS<T> where T : class
    {
        Task<T> Create(T t);

        Task<IQueryable<T>> Read(T t);

        Task<IQueryable<T>> Read( );

        Task<T> Upsert(T t);

        Task<bool> Delete(T t);
    }
}
