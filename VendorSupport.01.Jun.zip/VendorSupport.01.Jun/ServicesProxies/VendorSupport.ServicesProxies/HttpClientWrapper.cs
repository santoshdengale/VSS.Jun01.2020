﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace VendorSupport.ServicesProxies
{
    public class HttpClientWrapper : HttpClientBase, IHttpClientWrapper
    {
        public HttpClientWrapper(string baseURI = null) { }

        public async Task<HttpResponseMessage> DeleteAsyc(string apiURI)
        {
            return await HTTPClient.DeleteAsync(VendorServiceBaseURI + @"/" + apiURI);
        }

        public async Task<HttpResponseMessage> PutAsyc(string apiURI, string data)
        {
            return await HTTPClient.PutAsync(VendorServiceBaseURI + @"/" + apiURI, GetHTTPContent(data));
        }

        public async Task<HttpResponseMessage> PostAsyc(string apiURI, string data)
        {
            try
            {
                return await HTTPClient.PostAsync(VendorServiceBaseURI + @"/" + apiURI, GetHTTPContent(data));
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<string> GetStringAsync(string apiURI)
        {
            try
            {
                return await HTTPClient.GetStringAsync(VendorServiceBaseURI + @"/" + apiURI);
            }
            catch (Exception ex)
            {

                throw;
            }

        }

        #region IDisposable Pattern
        // Flag: Has Dispose already been called?
        bool disposed = false;

        // Public implementation of Dispose pattern callable by consumers.
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        // Protected implementation of Dispose pattern.
        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                // Free any other managed objects here.
                // 
                if (HTTPClient != null)
                    HTTPClient.Dispose();
            }

            // Free any unmanaged objects here.
            //
            disposed = true;
        }

        ~HttpClientWrapper()
        {
            Dispose(false);
        }
        #endregion IDisposable Pattern
    }
}
