﻿using System;
using System.Configuration;
using System.Net;
using System.Net.Http;

namespace VendorSupport.ServicesProxies
{
    public abstract class BaseProxy<T>
    {
        //ar client = new HttpClient()
        protected HttpClient HTTPClient { get; set; }
        protected WebClient WEBClient { get; set; }
        protected HttpWebRequest HTTPWebRequest { get; set; }

        private string vendorServiceBaseURI = string.Empty;
        
        public BaseProxy(string baseURI = null)
        {
            Init(baseURI);
        }

        private void Init(string baseURI)
        {
            if (!string.IsNullOrWhiteSpace(baseURI))
                vendorServiceBaseURI = baseURI;
            else
                vendorServiceBaseURI = ConfigurationManager.AppSettings["VendorServiceBaseURI"];

            HTTPClient = new HttpClient();
            HTTPClient.BaseAddress = new Uri(vendorServiceBaseURI);

            WEBClient = new WebClient();
            WEBClient.BaseAddress = vendorServiceBaseURI;
        }
    }
}
