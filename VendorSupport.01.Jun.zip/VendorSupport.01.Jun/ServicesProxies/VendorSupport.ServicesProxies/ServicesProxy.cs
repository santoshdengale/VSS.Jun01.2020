﻿using System;

namespace VendorSupport.ServicesProxies
{
    public class ServicesProxy<T> : BaseProxy<T>, IServicesProxy<T>, IDisposable
    {
        public ServicesProxy() : base() { }

        public ServicesProxy(string baseURI) { }

        public void Create(string uriString)
        {

            throw new NotImplementedException();
        }

        public T Read(string uriString)
        {
            //return WEBClient.DownloadData(uriString);
            throw new NotImplementedException();
        }

        public void Update(string uriString)
        {
            throw new NotImplementedException();
        }

        public void Delete(string uriString)
        {
            throw new NotImplementedException();
        }

        #region IDisposable Pattern
        // Flag: Has Dispose already been called?
        bool disposed = false;

        // Public implementation of Dispose pattern callable by consumers.
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        // Protected implementation of Dispose pattern.
        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                // Free any other managed objects here.
                //
                if (WEBClient != null)
                    WEBClient.Dispose();

                if (HTTPClient != null)
                    HTTPClient.Dispose();
            }

            // Free any unmanaged objects here.
            //
            disposed = true;
        }



        ~ServicesProxy()
        {
            Dispose(false);
        }
        #endregion IDisposable Pattern
    }
}
