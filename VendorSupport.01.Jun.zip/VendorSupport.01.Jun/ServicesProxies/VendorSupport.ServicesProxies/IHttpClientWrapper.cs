﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace VendorSupport.ServicesProxies
{
    public interface IHttpClientWrapper : IDisposable
    {
        Task<HttpResponseMessage> DeleteAsyc(string apiURI);

        Task<HttpResponseMessage> PutAsyc(string apiURI, string data);

        Task<HttpResponseMessage> PostAsyc(string apiURI, string data);

        Task<string> GetStringAsync(string apiURI);
    }
}
