﻿using System;
using System.Configuration;
using System.Net.Http;
using System.Net.Http.Headers;

namespace VendorSupport.ServicesProxies
{
    public abstract class HttpClientBase : IDisposable
    {

        protected const string JSON_FORMATTER = "application/json";
        protected const string XML_FORMATTER = "application/xml";


        public HttpClient HTTPClient { get; set; }
        protected string VendorServiceBaseURI { get; set; } = string.Empty;

        protected HttpMessageHandler HTTPMessageHandler { get; set; }

        public HttpClientBase(string baseURI = null)
        {
            Init(baseURI);
        }

        private void Init(string baseURI)
        {
            if (!string.IsNullOrWhiteSpace(baseURI))
                VendorServiceBaseURI = baseURI;
            else
                VendorServiceBaseURI = ConfigurationManager.AppSettings["VendorServiceBaseURI"];

            HTTPClient = new HttpClient();
            SetHttpClient();
        }

        private void SetHttpClient()
        {
            HTTPClient.BaseAddress = new Uri(VendorServiceBaseURI);
            HTTPClient.DefaultRequestHeaders.Accept.Clear();
            //HTTPClient.use
            HTTPClient.DefaultRequestHeaders.Accept.Add
               (new MediaTypeWithQualityHeaderValue(JSON_FORMATTER));
        }

        private void AddHeader(HttpRequestMessage request, string header, string country)
        {
            if (!string.IsNullOrWhiteSpace(country))
            {
                request.Headers.Add(header, country);
            }
        }


        protected HttpRequestMessage CreateRequestWithSetHeaders(HttpMethod method = null, string query = null,
            string country = null, string salesChannel = null, string partner = null,
            string language = null, string userName = null, string mediaType = null)
        {


            var request = new HttpRequestMessage(method, query);
            request.Headers.Accept.Clear();

            if (!string.IsNullOrWhiteSpace(mediaType))
            {
                request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue(JSON_FORMATTER));
            }

            return request;
        }

        protected HttpContent GetHTTPContent(string jsonObject)
        {
            HttpContent content = new StringContent(jsonObject);
            content.Headers.ContentType = new MediaTypeHeaderValue(JSON_FORMATTER);
            return content;
        }
        public virtual void Dispose() { }
    }
}
