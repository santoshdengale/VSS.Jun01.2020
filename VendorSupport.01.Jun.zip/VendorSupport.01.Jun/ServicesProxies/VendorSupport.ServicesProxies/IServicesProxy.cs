﻿
namespace VendorSupport.ServicesProxies
{
    public interface IServicesProxy<T>
    {
        void Create(string uriString);

        T Read(string uriString);

        void Update(string uriString);

        void Delete(string uriString);

        //void Create(T t,string uriString);

        //T Read(T t, string uriString);

        //void Update(T t, string uriString);

        //void Delete(T t, string uriString);
    }
}
