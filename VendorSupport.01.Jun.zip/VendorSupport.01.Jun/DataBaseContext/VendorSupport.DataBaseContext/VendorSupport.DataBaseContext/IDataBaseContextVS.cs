﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendorSupport.DataBaseContext
{
    public interface IDataBaseContextVS<T> where T : class
    {

        Task<T> Create(T t);

        Task<IQueryable<T>> Read(T t);

        Task<IQueryable<T>> Read();

        Task<T> Upsert(T t);

        Task<bool> Delete(T t);

        //Task<T> Create(T t);

        //Task<IQueryable<T>> Read(T t);

        //Task<IQueryable<T>> Read();

        //Task<T> Upsert(T t);

        //Task<bool> Delete(T t);

        //  Task<IQueryable<T>> Read(decimal code);
    }
}
