﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendorSupport.Entities;
using VendorSupport.EntityConfigs;

namespace VendorSupport.DataBaseContext
{
    public class DataBaseContextVS<T> : DataBaseContextBase, IDataBaseContextVS<T> where T : class
    {
        private readonly IDbSet<T> dbSetHandler;

        public DataBaseContextVS() : base("Name=VendorDbContext")
        {
            System.Data.Entity.Database.SetInitializer<DataBaseContextVS<T>>(null);
            dbSetHandler = base.Set<T>();
        }

        public DataBaseContextVS(string connectionString)
            : base(connectionString)
        {
        }

        public DataBaseContextVS(string connectionString, System.Data.Entity.Infrastructure.DbCompiledModel model)
            : base(connectionString, model)
        {
        }

        public DataBaseContextVS(System.Data.Common.DbConnection existingConnection, bool contextOwnsConnection)
            : base(existingConnection, contextOwnsConnection)
        {
        }

        public DataBaseContextVS(System.Data.Common.DbConnection existingConnection, System.Data.Entity.Infrastructure.DbCompiledModel model, bool contextOwnsConnection)
            : base(existingConnection, model, contextOwnsConnection)
        {
        }

        public DataBaseContextVS(System.Data.Entity.Core.Objects.ObjectContext objectContext, bool dbContextOwnsObjectContext)
            : base(objectContext, dbContextOwnsObjectContext)
        {
        }

        public bool IsSqlParameterNull(System.Data.SqlClient.SqlParameter param)
        {
            var sqlValue = param.SqlValue;
            var nullableValue = sqlValue as System.Data.SqlTypes.INullable;
            if (nullableValue != null)
                return nullableValue.IsNull;
            return (sqlValue == null || sqlValue == System.DBNull.Value);
        }

        public static System.Data.Entity.DbModelBuilder CreateModel(System.Data.Entity.DbModelBuilder modelBuilder, string schema)
        {
            //modelBuilder.Configurations.Add(new CommunicationDetailConfiguration(schema));
            //modelBuilder.Configurations.Add(new PersonalDetailConfiguration(schema));
            //modelBuilder.Configurations.Add(new UserDetailConfiguration(schema));
            //modelBuilder.Configurations.Add(new UserTypeDetailConfiguration(schema));

            modelBuilder.Configurations.Add(new AreaDetailConfiguration(schema));
            modelBuilder.Configurations.Add(new CityDetailConfiguration(schema));
            modelBuilder.Configurations.Add(new CommunicationDetailConfiguration(schema));
            modelBuilder.Configurations.Add(new CountryDetailConfiguration(schema));
            modelBuilder.Configurations.Add(new DistrictDetailConfiguration(schema));
            modelBuilder.Configurations.Add(new PersonalDetailConfiguration(schema));
            modelBuilder.Configurations.Add(new ServiceDetailConfiguration(schema));
            modelBuilder.Configurations.Add(new StateDetailConfiguration(schema));
            modelBuilder.Configurations.Add(new TahasilDetailConfiguration(schema));
            modelBuilder.Configurations.Add(new UserDetailConfiguration(schema));
            modelBuilder.Configurations.Add(new UserTypeDetailConfiguration(schema));
            modelBuilder.Configurations.Add(new VendorDetailConfiguration(schema));

            return modelBuilder;
        }

        #region Task Without Asyc Await
        public async Task<T> Create(T t)
        {
            // T result = default(T);
            Entry(t).State = EntityState.Added;
            var result = dbSetHandler.Add(t);
            await Save();
            return result;
        }

        public async Task<IQueryable<T>> Read(T t)
        {
            return await Task.Run(() =>
            {
                return base.Set<T>();
            });
        }

        public async Task<IQueryable<T>> Read()
        {
            return await Task.Run(() =>
            {
                return base.Set<T>();
            });
        }

        public async Task<T> Upsert(T t)
        {
            Entry(t).State = EntityState.Modified;
            await Save();
            return t;
        }

        public async Task<bool> Delete(T t)
        {
            Entry(t).State = EntityState.Deleted;
            await Save();
            return true;
        }

        private async Task Save()
        {
            try
            {

                await this.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                var res = ex;
                throw;
            }
        }
        #endregion  Task Without  Asyc Await



        #region Asyc Await
        //public async Task<T> Create(T t)
        //{
        //   // T result = default(T);
        //    Entry(t).State = EntityState.Added;
        //    var result = dbSetHandler.Add(t);
        //    await Save();
        //    return result;
        //}

        //public async Task<IQueryable<T>> Read(T t)
        //{ 
        // return await Task.Run(() => { 
        // return base.Set<T>();                    });
        //}

        //public async Task<IQueryable<T>> Read()
        //{
        //    return await Task.Run(() =>
        //   {
        //       return base.Set<T>();
        //   });
        //}

        //public async Task<T> Upsert(T t)
        //{
        //    Entry(t).State = EntityState.Modified;
        //    await Save();
        //    return t;
        //}

        //public async Task<bool> Delete(T t)
        //{
        //    Entry(t).State = EntityState.Deleted;
        //    await Save();
        //    return true;
        //}

        //private async Task Save()
        //{
        //    await Task.Run(() =>
        //  {
        //      this.SaveChanges();
        //  });
        //}
        #endregion Asyc Await


        #region IDisposable Pattern
        // Flag: Has Dispose already been called?
        bool disposed = false;
        // Instantiate a SafeHandle instance.


        // Public implementation of Dispose pattern callable by consumers.
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        // Protected implementation of Dispose pattern.
        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            //if (disposing)
            //    ((DataBaseContextVS<T>)dataBaseContext).Dispose();

            disposed = true;
        }



        #endregion IDisposable Pattern
    }
}