﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendorSupport.Entities;
using VendorSupport.EntityConfigs;

namespace VendorSupport.DataBaseContext
{
    [System.CodeDom.Compiler.GeneratedCode("EF.Reverse.POCO.Generator", "2.37.4.0")]
    public abstract class DataBaseContextBase : System.Data.Entity.DbContext
    { 
        static DataBaseContextBase()
        {
            //System.Data.Entity.Database.SetInitializer<DataBaseContextBase>(null);
          //  Configuration.LazyLoadingEnabled = true;
        }
        
        public DataBaseContextBase()
        {
            this.Configuration.LazyLoadingEnabled = true;

            //Configuration.LazyLoadingEnabled = false;
            //Configuration.ProxyCreationEnabled = true;
            //   Configuration.
            //Configuration.LazyLoadingEnabled = false;
            //Configuration.LazyLoadingEnabled = false;
        }

        public DataBaseContextBase(string connectionString)
            : base(connectionString)
        {
           // this.Configuration.LazyLoadingEnabled = true;
        }



        public DataBaseContextBase(string connectionString, System.Data.Entity.Infrastructure.DbCompiledModel model)
            : base(connectionString, model)
        {
        }

        public DataBaseContextBase(System.Data.Common.DbConnection existingConnection, bool contextOwnsConnection)
            : base(existingConnection, contextOwnsConnection)
        {
        }

        public DataBaseContextBase(System.Data.Common.DbConnection existingConnection, System.Data.Entity.Infrastructure.DbCompiledModel model, bool contextOwnsConnection)
            : base(existingConnection, model, contextOwnsConnection)
        {
        }

        public DataBaseContextBase(System.Data.Entity.Core.Objects.ObjectContext objectContext, bool dbContextOwnsObjectContext)
            : base(objectContext, dbContextOwnsObjectContext)
        {
        }



        protected override void OnModelCreating(System.Data.Entity.DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Configurations.Add(new AreaDetailConfiguration());
            modelBuilder.Configurations.Add(new CityDetailConfiguration());
            modelBuilder.Configurations.Add(new CommunicationDetailConfiguration());
            modelBuilder.Configurations.Add(new CountryDetailConfiguration());
            modelBuilder.Configurations.Add(new DistrictDetailConfiguration());
            modelBuilder.Configurations.Add(new PersonalDetailConfiguration());
            modelBuilder.Configurations.Add(new ServiceDetailConfiguration());
            modelBuilder.Configurations.Add(new StateDetailConfiguration());
            modelBuilder.Configurations.Add(new TahasilDetailConfiguration());
            modelBuilder.Configurations.Add(new UserDetailConfiguration());
            modelBuilder.Configurations.Add(new UserTypeDetailConfiguration());
            modelBuilder.Configurations.Add(new VendorDetailConfiguration());
        }


        //public System.Data.Entity.DbSet<CommunicationDetail> CommunicationDetails { get; set; } // CommunicationDetail
        //public System.Data.Entity.DbSet<PersonalDetail> PersonalDetails { get; set; } // PersonalDetail
        //public System.Data.Entity.DbSet<UserDetail> UserDetails { get; set; } // UserDetail
        //public System.Data.Entity.DbSet<UserTypeDetail> UserTypeDetails { get; set; } // UserTypeDetail

    }
}
