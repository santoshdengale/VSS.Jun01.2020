using System.Web.Http;
using Unity;
using Unity.WebApi;
using VendorSupport.BL;
using VendorSupport.BL.Interfaces;
using VendorSupport.DataBaseContext;
using VendorSupport.DL;
using VendorSupport.DL.Interfaces;
using VendorSupport.Entities;
using VendorSupport.Repositories;
using VendorSupport.Services.Controllers;

namespace VendorSupport.Services
{
    public static class UnityConfig
    {
        private static readonly IUnityContainer container = new UnityContainer();

        public static void RegisterComponents()
        {
            RegisterDL();
            RegisterBL();
            RegisterDbContext();
            RegisterRepository();
            GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);
        }

        private static void RegisterRepository()
        {
            //RepositoryVS<T> : BaseRepository<T>, IDisposable, IRepositoryVS
            container.RegisterType<IRepositoryVS<BaseEntity>, RepositoryVS<BaseEntity>>();

            container.Resolve<UserTypeDL>();
            container.Resolve<UserDL>();

        }

        private static void RegisterDL()
        {
            container.RegisterType<ICommunicationDL, CommunicationDL>();
            container.RegisterType<IPersonalDL, PersonalDL>();
            container.RegisterType<IUserTypeDL, UserTypeDL>();
            container.RegisterType<IUserDL, UserDL>();

            container.Resolve<UserTypeBL>();
            container.Resolve<UserBL>();

            container.RegisterType<IServiceDL, ServiceDL>(); 
            container.Resolve<ServiceBL>();

            container.RegisterType<IVendorDL, VendorDL>();
            container.Resolve<VendorBL>();

            container.RegisterType<ICountryDL, CountryDL>();
            container.Resolve<CountryBL>();

            container.RegisterType<IStateDL, StateDL>();
            container.Resolve<StateBL>();

            container.RegisterType<ICityDL, CityDL>();
            container.Resolve<CityBL>();
        }

        private static void RegisterBL()
        {
            container.RegisterType<ICommunicationBL, CommunicationBL>();
            container.RegisterType<IPersonalBL, PersonalBL>();
            container.RegisterType<IUserTypeBL, UserTypeBL>();
            container.RegisterType<IUserBL, UserBL>();
            container.RegisterType<IAreaBL, AreaBL>();

            container.Resolve<UsersAPIController>();
            container.Resolve<UserTypesAPIController>();
            container.Resolve<AreasAPIController>();

            container.RegisterType<IServiceBL, ServiceBL>();
            container.Resolve<ServicesAPIController>();

            container.RegisterType<IVendorBL, VendorBL>();
            container.Resolve<VendorsAPIController>();

            container.RegisterType<ICountryBL, CountryBL>();
            container.Resolve<CountriesAPIController>();

            container.RegisterType<IStateBL, StateBL>();
            container.Resolve<StatesAPIController>();

            container.RegisterType<ICityBL, CityBL>();
            container.Resolve<CitiesAPIController>();
        }

        private static void RegisterDbContext()
        {
            //container.RegisterType<IDataBaseContextVS<BaseEntity>, DataBaseContextVS<BaseEntity>>();

            //container.Resolve<UserTypeAPIController>();

        }
    }
}