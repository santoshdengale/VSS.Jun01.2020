﻿using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using VendorSupport.BL.Interfaces;
using VendorSupport.Common;
using VendorSupport.ConvertModelEntity;
using VendorSupport.Entities;
using VendorSupport.Models;
using VendorSupport.Utilities;

namespace VendorSupport.Services.Controllers
{
    [RoutePrefix("API/Services")]
    public class ServicesAPIController : BaseAPIController
    {
        private readonly IServiceBL iBussLayer;
        
        public ServicesAPIController(IServiceBL iBLayer)
        {
            //iBussLayer = new ServiceBL();
            iBussLayer = iBLayer;
        }

        [Route("GetServices")]
        public async Task<IHttpActionResult> Get()
        {
            List<ServiceDetail> entities  =  await iBussLayer.Read();
            IEnumerable<ServiceDetailModel> models = ServiceConverter.Convert(entities);
            return Ok(models);
        }

        [Route("PostService")]
        public async Task<IHttpActionResult> Post([FromBody] ServiceDetailModel model)
        {
              CRUDMessage messageHandler = await iBussLayer.Create(ServiceConverter.Convert(model));
            if (messageHandler.MessageStutus == EnumMessageStutus.Valid)
                return Ok(model);
            else
                return BadRequest(messageHandler.Message);
        }

        [Route("PutService")]
        public async Task<IHttpActionResult> Put([FromBody] ServiceDetailModel model)
        {
            CRUDMessage messageHandler = await iBussLayer.Upsert(ServiceConverter.Convert(model));
            if (messageHandler.MessageStutus == EnumMessageStutus.Valid)
                return Ok(model);
            else
                return BadRequest(messageHandler.Message);
        }

        // GET: api/Service/5
        [Route("GetService/{id}")]
        public async Task<IHttpActionResult> Get(int id)
        {
            ServiceDetailModel model = ServiceConverter.Convert(await iBussLayer.Read(id));
            if (model != null)
                return Ok(model);
            else
                return BadRequest();

        }

        // DELETE: api/Service/5
        public void Delete(int id)
        {
        }
    }
}