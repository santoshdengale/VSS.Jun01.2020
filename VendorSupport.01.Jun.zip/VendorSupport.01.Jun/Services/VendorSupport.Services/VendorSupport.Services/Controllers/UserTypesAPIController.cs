﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using VendorSupport.BL.Interfaces;
using VendorSupport.Common;
using VendorSupport.ConvertModelEntity;
using VendorSupport.Entities;
using VendorSupport.Models;

namespace VendorSupport.Services.Controllers
{
    [RoutePrefix("API/UserTypes")]
    public class UserTypesAPIController : BaseAPIController
    {
        private readonly IUserTypeBL iBussLayer;
        public UserTypesAPIController(IUserTypeBL iBLayer)
        {
            //iBussLayer = new UserTypeBL();
            iBussLayer = iBLayer;
        }

        [Route("GetUsersType")]
        public async Task<IHttpActionResult> Get()
        {
            UserTypeDetail userType = new UserTypeDetail();
            IEnumerable<UserTypeDetailModel> userTypeDetails = UserTypeConverter.Convert(await iBussLayer.Read(userType));
            return Ok(userTypeDetails);
        }

        [Route("PostUserType")]
        public async Task<IHttpActionResult> Post([FromBody] UserTypeDetailModel model)
        {
            UserTypeDetail entity = UserTypeConverter.Convert(model);
            CRUDMessage messageHandler = await iBussLayer.Create(entity);
            if (messageHandler.MessageStutus == EnumMessageStutus.Valid)
                return Ok(model);
            else
                return BadRequest(messageHandler.Message);
        }

        [Route("PutUserType")]
        public async Task<IHttpActionResult> Put([FromBody] UserTypeDetailModel model)
        {
            var entity = UserTypeConverter.Convert(model);
            CRUDMessage messageHandler = await iBussLayer.Upsert(entity);
            if (messageHandler.MessageStutus == EnumMessageStutus.Valid)
                return Ok(model);
            else
                return BadRequest(messageHandler.Message);
        }

        // GET: api/UserType/5
        [Route("GetUserType/{id}")]
        public async Task<IHttpActionResult> Get(int id)
        {
            var entity = new UserTypeDetail();
            IEnumerable<UserTypeDetailModel> userTypeDetails = UserTypeConverter.Convert(await iBussLayer.Read(entity));
            if (userTypeDetails != null && userTypeDetails.Count() > 0)
                return Ok(userTypeDetails.FirstOrDefault());
            else
                return BadRequest();

        }

        // DELETE: api/UserType/5
        public void Delete(int id)
        {
        }
    }
}
