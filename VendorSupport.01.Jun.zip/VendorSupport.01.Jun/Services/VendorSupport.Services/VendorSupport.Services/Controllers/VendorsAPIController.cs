﻿using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using VendorSupport.BL.Interfaces;
using VendorSupport.Common;
using VendorSupport.ConvertModelEntity;
using VendorSupport.Entities;
using VendorSupport.Models;
using VendorSupport.Utilities;
 
namespace VendorSupport.Services.Controllers
{
    [RoutePrefix("API/Vendors")]
    public class VendorsAPIController : BaseAPIController  // ApiController
    {
        private readonly IVendorBL iBussLayer;
        public VendorsAPIController(IVendorBL iBLayer)
        {
            //iBussLayer = new VendorBL();
            iBussLayer = iBLayer;
        }

        [Route("GetVendors")]
        public async Task<IHttpActionResult> Get()
        { 
            //IEnumerable<VendorDetail> entities = await iBussLayer.Read(); 
            IEnumerable<VendorDetailModel> models = VendorConverter.Convert(await iBussLayer.Read() /*entities*/); 
            return Ok(models);
        }

        [Route("PostVendor")]
        public async Task<IHttpActionResult> Post([FromBody] VendorDetailModel model)
        {
            VendorDetail entity = VendorConverter.Convert(model);

            CRUDMessage messageHandler = await iBussLayer.Create(entity);
            if (messageHandler.MessageStutus == EnumMessageStutus.Valid)
                return Ok(model);
            else
                return BadRequest(messageHandler.Message);
        }

        [Route("PutVendor")]
        public async Task<IHttpActionResult> Put([FromBody] VendorDetailModel model)
        {
            //var entity = VendorConverter.Convert(model);
            VendorDetail entity =
               AutoMapperUtility<VendorDetailModel, VendorDetail>.Mapper(model);
            CRUDMessage messageHandler = await iBussLayer.Upsert(entity);
            if (messageHandler.MessageStutus == EnumMessageStutus.Valid)
                return Ok(model);
            else
                return BadRequest(messageHandler.Message);
        }

        // GET: api/Vendor/5
        [Route("GetVendor/{id}")]
        public async Task<IHttpActionResult> Get(int id)
        {
            VendorDetail entity = await iBussLayer.Read(id);
            VendorDetailModel model = AutoMapperUtility<VendorDetail, VendorDetailModel>.Mapper(entity);
            if (model != null)
                return Ok(model);
            else
                return BadRequest();

        }

        // DELETE: api/Vendor/5
        public void Delete(int id)
        {
        }
    }
}