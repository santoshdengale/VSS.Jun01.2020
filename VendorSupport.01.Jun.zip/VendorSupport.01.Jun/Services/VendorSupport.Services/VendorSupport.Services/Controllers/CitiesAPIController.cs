﻿using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using VendorSupport.BL.Interfaces;
using VendorSupport.Common;
using VendorSupport.ConvertModelEntity;
using VendorSupport.Entities;
using VendorSupport.Models;
using VendorSupport.Utilities;

namespace VendorSupport.Services.Controllers
{
    [RoutePrefix("API/Citys")]
    public class CitiesAPIController : BaseAPIController
    {
        private readonly ICityBL iBussLayer;
        public CitiesAPIController(ICityBL iBLayer)
        {
            //iBussLayer = new CityBL();
            iBussLayer = iBLayer;
        }

        [HttpGet]
        [Route("GetCitys")]
        public async Task<IHttpActionResult> Get()
        {
            CityDetail City = new CityDetail();
            IEnumerable<CityDetail> entities = await iBussLayer.Read(City);
            //IEnumerable<CityDetailModel> models =
            //    AutoMapperUtility<IEnumerable<CityDetail>, IEnumerable<CityDetailModel>>.Mapper(entities);

            IEnumerable<CityDetailModel> models = CityConverter.Convert(entities);

            return Ok(models);
        }

        [HttpPost]
        [Route("PostCity")]
        public async Task<IHttpActionResult> Post([FromBody] CityDetailModel model)
        {
            //CityDetail entity =
            //   AutoMapperUtility<CityDetailModel, CityDetail>.Mapper(model);

            CityDetail entity =              CityConverter.Convert(model);

            CRUDMessage messageHandler = await iBussLayer.Create(entity);
            if (messageHandler.MessageStutus == EnumMessageStutus.Valid)
                return Ok(model);
            else
                return BadRequest(messageHandler.Message);
        }

        [HttpPut]
        [Route("PutCity")]
        public async Task<IHttpActionResult> Put([FromBody] CityDetailModel model)
        {
            //var entity = CityConverter.Convert(model);
            CityDetail entity =
               AutoMapperUtility<CityDetailModel, CityDetail>.Mapper(model);
            CRUDMessage messageHandler = await iBussLayer.Upsert(entity);
            if (messageHandler.MessageStutus == EnumMessageStutus.Valid)
                return Ok(model);
            else
                return BadRequest(messageHandler.Message);
        }

        // GET: api/City/5
        [HttpGet]
        [Route("GetCity/{id}")]
        public async Task<IHttpActionResult> Get(int id)
        {
            CityDetail entity = await iBussLayer.Read(id);
            CityDetailModel model = AutoMapperUtility<CityDetail, CityDetailModel>.Mapper(entity);
            if (model != null)
                return Ok(model);
            else
                return BadRequest();

        }

        [HttpDelete]
        // DELETE: api/City/5
        public void Delete(int id)
        {
        }
    }
}