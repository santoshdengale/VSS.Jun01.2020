﻿using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using VendorSupport.BL.Interfaces;
using VendorSupport.Common;
using VendorSupport.ConvertModelEntity;
using VendorSupport.Models;

namespace VendorSupport.Services.Controllers
{
    [RoutePrefix("API/Users")]
    public class UsersAPIController : BaseAPIController
    {
        private readonly IUserBL iBussLayer;

        public UsersAPIController(IUserBL iBLayer)
        {
            // iBussLayer = new UserBL();
            iBussLayer = iBLayer;
        }

        [HttpGet]
        [Route("GetUsers")]
        public async Task<IHttpActionResult> Get()
        {
            try
            {
                var entites = await iBussLayer.Read();
                IEnumerable<UserDetailModel> models = UserConverter.Convert(entites);
                return Ok(models);
            }
            catch (System.Exception ex)
            {

                throw;
            }

        }

        [HttpPost]
        [Route("PostUser")]
        public async Task<IHttpActionResult> Post([FromBody] UserDetailModel model)
        {
            // UserConverter.CommonConverter(model)
            var entity = UserConverter.Convert(model);
            BaseConveters.CommonConverter(model.CommunicationDetail);
            BaseConveters.CommonConverter(model.PersonalDetail);
            CRUDMessage messageHandler = await iBussLayer.Create(entity);

            if (messageHandler.MessageStutus == EnumMessageStutus.Valid)
                return Ok(model);
            else
                return BadRequest(messageHandler.Message);
        }

        [HttpPut]
        [Route("PutUser")]
        public async Task<IHttpActionResult> Put([FromBody] UserDetailModel model)
        {
            var entity = UserConverter.Convert(model);
            BaseConveters.CommonConverter(model.CommunicationDetail);
            BaseConveters.CommonConverter(model.PersonalDetail);

            CRUDMessage messageHandler = await iBussLayer.Upsert(entity);
            if (messageHandler.MessageStutus == EnumMessageStutus.Valid)
                return Ok(model);
            else
                return BadRequest(messageHandler.Message);
        }

        [HttpGet]
        [Route("GetUser/{id}")]
        public async Task<IHttpActionResult> Get(int id)
        {
            var model = UserConverter.Convert(await iBussLayer.Read(id));
            if (model != null)
                return Ok(model);
            else
                return BadRequest();

        }

        [HttpDelete]
        [Route("DeleteUser/{id}")]
        public void Delete(int id)
        {
            //CRUDMessage messageHandler = iBussLayer.Delete(id);
            //if (messageHandler.MessageStutus == EnumMessageStutus.Valid)
            //    return Ok(model);
            //else
            //    return BadRequest(messageHandler.Message);

        }

        [Route("UserLogin")]
        [HttpPost]
        public async Task<IHttpActionResult> Login(UserDetailModel model)
        {
            var entity = await iBussLayer.Login(UserConverter.Convert(model));
            var modelResult = UserConverter.Convert(entity);
            if (modelResult != null)
                return Ok(modelResult);
            else
                return BadRequest("Unable to find : " + model.Name);
        }


        [Route("ChangeUserPassword")]
        [HttpPost]
        public async Task<IHttpActionResult> ChangePassword(UserDetailModel model)
        {
            var entity = await iBussLayer.ChangePassword(UserConverter.Convert(model));
            if (entity)
                return Ok(entity);
            else
                return BadRequest("Unable to find : " + model.Name +  "  and ,  " + model.CommunicationDetail.Email1);
        }
    }
}

