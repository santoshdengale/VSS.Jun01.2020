﻿using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using VendorSupport.BL.Interfaces;
using VendorSupport.Common;
using VendorSupport.ConvertModelEntity;
using VendorSupport.Entities;
using VendorSupport.Models;
using VendorSupport.Utilities;

namespace VendorSupport.Services.Controllers
{
    [RoutePrefix("API/Areas")]
    public class AreasAPIController : BaseAPIController
    {
        private readonly IAreaBL iBussLayer;
        public AreasAPIController(IAreaBL iBLayer)
        {
            //iBussLayer = new AreaBL();
            iBussLayer = iBLayer;
        }

        [Route("GetAreas")]
        [HttpGet]
        public async Task<IHttpActionResult> Get()
        {
            AreaDetail Area = new AreaDetail();
            IEnumerable<AreaDetail> entities = await iBussLayer.Read();
            //IEnumerable<AreaDetailModel> models =
            //    AutoMapperUtility<IEnumerable<AreaDetail>, IEnumerable<AreaDetailModel>>.Mapper(entities);
            IEnumerable<AreaDetailModel> models =
               AreaConverter.Convert(entities);
            return Ok(models);
        }

        [Route("PostArea")]
        [HttpPost]
        public async Task<IHttpActionResult> Post([FromBody] AreaDetailModel model)
        {
            //AreaDetail entity =
            //   AutoMapperUtility<AreaDetailModel, AreaDetail>.Mapper(model);

            AreaDetail entity = AreaConverter.Convert(model);

            CRUDMessage messageHandler = await iBussLayer.Create(entity);
            if (messageHandler.MessageStutus == EnumMessageStutus.Valid)
                return Ok(model);
            else
                return BadRequest(messageHandler.Message);
        }

        [Route("PutArea")]
        [HttpPut]
        public async Task<IHttpActionResult> Put([FromBody] AreaDetailModel model)
        {
            //var entity = AreaConverter.Convert(model);
            //AreaDetail entity =
            //   AutoMapperUtility<AreaDetailModel, AreaDetail>.Mapper(model);

            AreaDetail entity =
             AreaConverter.Convert(model);

            CRUDMessage messageHandler = await iBussLayer.Upsert(entity);
            if (messageHandler.MessageStutus == EnumMessageStutus.Valid)
                return Ok(model);
            else
                return BadRequest(messageHandler.Message);
        }

        // GET: api/Area/5
        [Route("GetArea/{id}")]
        [HttpGet]
        public async Task<IHttpActionResult> Get(int id)
        {
            AreaDetail entity = await iBussLayer.Read(id);
            AreaDetailModel model = AutoMapperUtility<AreaDetail, AreaDetailModel>.Mapper(entity);
            if (model != null)
                return Ok(model);
            else
                return BadRequest();

        }

        // DELETE: api/Area/5
        [HttpDelete]
        public void Delete(int id)
        {
        }
    }
}
