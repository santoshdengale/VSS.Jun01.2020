﻿using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using VendorSupport.BL.Interfaces;
using VendorSupport.Common;
using VendorSupport.ConvertModelEntity;
using VendorSupport.Entities;
using VendorSupport.Models;
using VendorSupport.Utilities;

namespace VendorSupport.Services.Controllers
{
    [RoutePrefix("API/States")]
    public class StatesAPIController : BaseAPIController
    {
        private readonly IStateBL iBussLayer;
        public StatesAPIController(IStateBL iBLayer)
        {
            //iBussLayer = new StateBL();
            iBussLayer = iBLayer;
        }

        [HttpGet]
        [Route("GetStates")]
        public async Task<IHttpActionResult> Get()
        {
             IEnumerable<StateDetail> entities = await iBussLayer.Read();
            IEnumerable<StateDetailModel> models =
                StateConverter.Convert(entities);
               // AutoMapperUtility<IEnumerable<StateDetail>, IEnumerable<StateDetailModel>>.Mapper(entities);
            return Ok(models);
        }

        [HttpPost]
        [Route("PostState")]
        public async Task<IHttpActionResult> Post([FromBody] StateDetailModel model)
        {
            StateDetail entity =
               StateConverter.Convert(model); 

            CRUDMessage messageHandler = await iBussLayer.Create(entity);
            if (messageHandler.MessageStutus == EnumMessageStutus.Valid)
                return Ok(model);
            else
                return BadRequest(messageHandler.Message);
        }

        [HttpPut]
        [Route("PutState")]
        public async Task<IHttpActionResult> Put([FromBody] StateDetailModel model)
        {
            //var entity = StateConverter.Convert(model);
            StateDetail entity =
               AutoMapperUtility<StateDetailModel, StateDetail>.Mapper(model);
            CRUDMessage messageHandler = await iBussLayer.Upsert(entity);
            if (messageHandler.MessageStutus == EnumMessageStutus.Valid)
                return Ok(model);
            else
                return BadRequest(messageHandler.Message);
        }

        // GET: api/State/5
        [HttpGet]
        [Route("GetState/{id}")]
        public async Task<IHttpActionResult> Get(int id)
        {
            StateDetail entity = await iBussLayer.Read(id);
            StateDetailModel model = AutoMapperUtility<StateDetail, StateDetailModel>.Mapper(entity);
            if (model != null)
                return Ok(model);
            else
                return BadRequest();

        }

        [HttpDelete]
        // DELETE: api/State/5
        public void Delete(int id)
        {
        }
    }
}
