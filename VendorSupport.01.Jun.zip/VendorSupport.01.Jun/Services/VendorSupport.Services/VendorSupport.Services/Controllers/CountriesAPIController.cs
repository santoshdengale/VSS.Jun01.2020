﻿using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using VendorSupport.BL.Interfaces;
using VendorSupport.Common;
using VendorSupport.ConvertModelEntity;
using VendorSupport.Entities;
using VendorSupport.Models;
using VendorSupport.Utilities;

namespace VendorSupport.Services.Controllers
{
    [RoutePrefix("API/Countries")]
    public class CountriesAPIController : BaseAPIController 
    {
        private readonly ICountryBL iBussLayer;
        public CountriesAPIController(ICountryBL iBLayer)
        {
            //iBussLayer = new CountryBL();
            iBussLayer = iBLayer;
        }

        [Route("GetCountries")]
        public async Task<IHttpActionResult> Get()
        {
              IEnumerable<CountryDetail> entities = await iBussLayer.Read(); 
            IEnumerable<CountryDetailModel> models =
                 CountryConverter.Convert(entities);
            return Ok(models);
        }

        [Route("PostCountry")]
        public async Task<IHttpActionResult> Post([FromBody] CountryDetailModel model)
        {
            CountryDetail entity =
              CountryConverter.Convert(model);

            CRUDMessage messageHandler = await iBussLayer.Create(entity);
            if (messageHandler.MessageStutus == EnumMessageStutus.Valid)
                return Ok(model);
            else
                return BadRequest(messageHandler.Message);
        }

        [Route("PutCountry")]
        public async Task<IHttpActionResult> Put([FromBody] CountryDetailModel model)
        {
            //var entity = CountryConverter.Convert(model);
            CountryDetail entity =
               AutoMapperUtility<CountryDetailModel, CountryDetail>.Mapper(model);
            CRUDMessage messageHandler = await iBussLayer.Upsert(entity);
            if (messageHandler.MessageStutus == EnumMessageStutus.Valid)
                return Ok(model);
            else
                return BadRequest(messageHandler.Message);
        }

        // GET: api/Country/5
        [Route("GetCountry/{id}")]
        public async Task<IHttpActionResult> Get(int id)
        {
            CountryDetail entity = await iBussLayer.Read(id);
            CountryDetailModel model = AutoMapperUtility<CountryDetail, CountryDetailModel>.Mapper(entity);
            if (model != null)
                return Ok(model);
            else
                return BadRequest();

        }

        // DELETE: api/Country/5
        public void Delete(int id)
        {
        }
    }
}
