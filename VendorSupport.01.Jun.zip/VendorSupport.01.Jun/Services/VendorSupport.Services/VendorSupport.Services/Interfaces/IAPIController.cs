﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace VendorSupport.Services.Interfaces
{
    public interface IAPIController
    {
        //Task<IHttpActionResult> Get();
        //Task<IHttpActionResult> Post(UserTypeDetailModel model);
        //    Task<IHttpActionResult> Put(UserTypeDetailModel model); 
        //Task<IHttpActionResult Get(int id) 
    }
}
