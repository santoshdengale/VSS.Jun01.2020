﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.DL.Interfaces;
using VendorSupport.Entities;
using VendorSupport.Repositories;

namespace VendorSupport.DL
{
    public class AreaDL : BaseDL, IAreaDL
    {
        public async Task<AreaDetail> Create(AreaDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<AreaDetail>())
            {
                entity.CityDetail = null;
                return await iRepositoryVS.Create(entity);
            }
        }

        public async Task<bool> Delete(AreaDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<AreaDetail>())
            {
                return await iRepositoryVS.Delete(entity);
            }
        }

        public async Task<IEnumerable<AreaDetail>> Read(AreaDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<AreaDetail>())
            {
                return await iRepositoryVS.Read(entity);
            }
        }

        public async Task<IEnumerable<AreaDetail>> Read()
        {
            using (var iRepositoryVS = new RepositoryVS<AreaDetail>())
            {
                var entities = await iRepositoryVS.Read();
                return entities.ToList();
            }
        }



        public async Task<AreaDetail> Upsert(AreaDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<AreaDetail>())
            {
                return await iRepositoryVS.Upsert(entity);
            }
        }


        public async Task<AreaDetail> Read(decimal code)
        {
            using (var iRepositoryVS = new RepositoryVS<AreaDetail>())
            {
                var result = await iRepositoryVS.Read();
                return result.FirstOrDefault(e => e.Code == code);
            }
        }
    }
}