﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.DL.Interfaces;
using VendorSupport.Entities;
using VendorSupport.Repositories;

namespace VendorSupport.DL
{
    public class ServiceDL : BaseDL, IServiceDL
    {
       // private readonly IRepositoryVS<ServiceDetail> iRepositoryVS = null; // new RepositoryVS<ServiceDetail>();
        public ServiceDL( )
        {
         //   iRepositoryVS = new RepositoryVS<ServiceDetail>();
        }

        public async Task<ServiceDetail> Create(ServiceDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<ServiceDetail>())
            {
                return await iRepositoryVS.Create(entity);
            }
        }

        public async Task<bool> Delete(ServiceDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<ServiceDetail>())
            {
                return await iRepositoryVS.Delete(entity);
            }
        }

        public async Task<IEnumerable<ServiceDetail>> Read(ServiceDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<ServiceDetail>())
            {
                return await iRepositoryVS.Read(entity);
            }
        }

        public async Task<IEnumerable<ServiceDetail>> Read()
        //public async Task<List<ServiceDetail>> Read()
        {
            using (var iRepositoryVS = new RepositoryVS<ServiceDetail>())
            {
                return await iRepositoryVS.Read();
            }

            //////IQueryable<ServiceDetail> enties = null;
            //////using (var iRepositoryVS = new RepositoryVS<ServiceDetail>())
            //////{
            ////    var  enties = await iRepositoryVS.Read();
            //////}  
            //try
            //{
            //    IQueryable<ServiceDetail> enties = await iRepositoryVS.Read();
            //    return enties.ToList();
            //}
            //catch (System.Exception ex)
            //{

            //    throw;
            //}

            //return null;

        }



        public async Task<ServiceDetail> Upsert(ServiceDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<ServiceDetail>())
            {
                return await iRepositoryVS.Upsert(entity);
            }
        }


        public async Task<ServiceDetail> Read(decimal code)
        {
            using (var iRepositoryVS = new RepositoryVS<ServiceDetail>())
            {
                var result = await iRepositoryVS.Read();
                return result.FirstOrDefault(e => e.Code == code);
            }
        }
    }
}