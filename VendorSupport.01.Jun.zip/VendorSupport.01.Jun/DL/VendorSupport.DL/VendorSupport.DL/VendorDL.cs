﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.DL.Interfaces;
using VendorSupport.Entities;
using VendorSupport.Repositories;

namespace VendorSupport.DL
{
    public class VendorDL : BaseDL, IVendorDL
    {
        public async Task<VendorDetail> Create(VendorDetail entity)
        {
            CommunicationDetail communication = null;
            if (entity.CommunicationDetail != null)
            {
                using (var iRepositoryVS = new RepositoryVS<CommunicationDetail>())
                {
                    communication = await iRepositoryVS.Create(entity.CommunicationDetail);
                }
            }

            PersonalDetail personal = null;
            if (entity.PersonalDetail != null)
            {
                using (var iRepositoryVS = new RepositoryVS<PersonalDetail>())
                {
                    personal = await iRepositoryVS.Create(entity.PersonalDetail);
                }
            }
           UserDetail  user = null;
            if (entity.UserDetail != null)
                user = await SetUserDetail(entity.UserDetail);

            using (var iRepositoryVS = new RepositoryVS<VendorDetail>())
            {
                if (communication != null)
                    entity.CommCode = communication.Code;

                if (personal != null)
                    entity.PersonalCode = personal.Code;

                if (user != null)
                    entity.UserCode = user.Code;

                entity.CommunicationDetail = null;
                entity.PersonalDetail = null;
                entity.UserDetail = null;

                return await iRepositoryVS.Create(entity);
            }
        }

        public async Task<bool> Delete(VendorDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<VendorDetail>())
            {
                return await iRepositoryVS.Delete(entity);
            }
        }

        public async Task<IEnumerable<VendorDetail>> Read(VendorDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<VendorDetail>())
            {
                return await iRepositoryVS.Read(entity);
            }
        }

        public async Task<IEnumerable<VendorDetail>> Read()
        {
            try
            {
                using (var iRepositoryVS = new RepositoryVS<VendorDetail>())
                {
                    var entities = await iRepositoryVS.Read();
                    var result = entities.ToList();
                    return entities.ToList();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }



        public async Task<VendorDetail> Upsert(VendorDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<VendorDetail>())
            {
                return await iRepositoryVS.Upsert(entity);
            }
        }


        public async Task<VendorDetail> Read(decimal code)
        {
            using (var iRepositoryVS = new RepositoryVS<VendorDetail>())
            {
                var result = await iRepositoryVS.Read();
                return result.FirstOrDefault(e => e.Code == code);
            }
        }

        private async Task<UserDetail> SetUserDetail(UserDetail entity)
        {
            UserDetail user = null;
            if (entity == null) return user;
            using (var iRepositoryVS = new RepositoryVS<UserDetail>())
            {
                entity.CommCode = null;
                entity.CommunicationDetail = null;
                entity.PersonalCode = null;
                entity.PersonalCode = null;
                entity.UserCode = null;
                entity.UserTypeCode = entity.UserTypeCode ==null ?  (decimal)Common.EnumUserType.Vendor : entity.UserTypeCode;
                user = await iRepositoryVS.Create(entity);
            }
            return user;
        }
    }
}