﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.DL.Interfaces;
using VendorSupport.Entities;
using VendorSupport.Repositories;

namespace VendorSupport.DL
{
    public class UserTypeDL : BaseDL, IUserTypeDL
    {
        public UserTypeDL() { }

        public async Task<UserTypeDetail> Create(UserTypeDetail userType)
        {
            using (var iRepositoryVS = new RepositoryVS<UserTypeDetail>())
            {
                return await iRepositoryVS.Create(userType);
            }
        }

        public async Task<bool> Delete(UserTypeDetail userType)
        {
            using (var iRepositoryVS = new RepositoryVS<UserTypeDetail>())
            {
                return await iRepositoryVS.Delete(userType);
            }
        }


        public async Task<UserTypeDetail> Upsert(UserTypeDetail userType)
        {
            using (var iRepositoryVS = new RepositoryVS<UserTypeDetail>())
            {
                return await iRepositoryVS.Upsert(userType);
            }
        }

        public async Task<IEnumerable<UserTypeDetail>> Read(UserTypeDetail userType)
        {
            using (var iRepositoryVS = new RepositoryVS<UserTypeDetail>())
            {
                return await iRepositoryVS.Read(userType);
            }
        }

        public async Task<IEnumerable<UserTypeDetail>> Read()
        {
            using (var iRepositoryVS = new RepositoryVS<UserTypeDetail>())
            {
                return await iRepositoryVS.Read();
            }
        }

        public async Task<UserTypeDetail> Read(decimal code)
        {
            using (var iRepositoryVS = new RepositoryVS<UserTypeDetail>())
            {
                var result = await iRepositoryVS.Read();
                return result.FirstOrDefault(e => e.Code == code);
            }
        }


        public async Task<UserTypeDetail> GetAdminType()
        {
            using (var iRepositoryVS = new RepositoryVS<UserTypeDetail>())
            {
                var result = await iRepositoryVS.Read();
                return result.FirstOrDefault(e => e.Code == (decimal)Common.EnumUserType.Administrator);
            }
        }
    }
}
