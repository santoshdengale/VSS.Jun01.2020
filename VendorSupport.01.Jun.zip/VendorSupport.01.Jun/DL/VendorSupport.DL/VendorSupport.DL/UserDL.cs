﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendorSupport.DL.Interfaces;
using VendorSupport.Entities;
using VendorSupport.Repositories;

namespace VendorSupport.DL
{
    public class UserDL : BaseDL, IUserDL
    {
        public async Task<UserDetail> Create(UserDetail entity)
        {
            CommunicationDetail communication = null;
            if (entity.CommunicationDetail != null)
            {
                using (var iRepositoryVS = new RepositoryVS<CommunicationDetail>())
                {
                    communication = await iRepositoryVS.Create(entity.CommunicationDetail);
                }
            }
            PersonalDetail personal = null;
            if (entity.PersonalDetail != null)
            {
                using (var iRepositoryVS = new RepositoryVS<PersonalDetail>())
                {
                    personal = await iRepositoryVS.Create(entity.PersonalDetail);
                }
            }

            using (var iRepositoryVS = new RepositoryVS<UserDetail>())
            {
                if (communication != null)
                    entity.CommCode = communication.Code;

                if (personal != null)
                    entity.PersonalCode = personal.Code;

                entity.CommunicationDetail = null;
                entity.PersonalDetail = null;
                entity.UserTypeDetail = null;
                entity.VendorDetails = null;

                return await iRepositoryVS.Create(entity);
            }
        }

        public async Task<bool> Delete(UserDetail user)
        {
            using (var iRepositoryVS = new RepositoryVS<UserDetail>())
            {
                return await iRepositoryVS.Delete(user);
            }
        }

        public async Task<IEnumerable<UserDetail>> Read(UserDetail user)
        {
            using (var iRepositoryVS = new RepositoryVS<UserDetail>())
            {
                return await iRepositoryVS.Read(user);
            }
        }

        public async Task<IEnumerable<UserDetail>> Read()
        {
            try
            {
                using (var iRepositoryVS = new RepositoryVS<UserDetail>())
                {
                    var entities = await iRepositoryVS.Read();
                    return entities.ToList();
                }
            }
            catch (Exception ex)
            {

                throw;
            }

        }

        public async Task<UserDetail> Read(decimal code)
        {
            using (var iRepositoryVS = new RepositoryVS<UserDetail>())
            {
                var result = await iRepositoryVS.Read();
                return result.FirstOrDefault(e => e.Code == code);
            }
        }

        public async Task<UserDetail> Upsert(UserDetail user)
        {
            using (var iRepositoryVS = new RepositoryVS<UserDetail>())
            {
                return await iRepositoryVS.Upsert(user);
            }
        }

        public async Task<UserDetail> Login(UserDetail user)
        {
            using (var iRepositoryVS = new RepositoryVS<UserDetail>())
            {
                //return await iRepositoryVS.Read(user);
                var entities = await iRepositoryVS.Read();
                var entity = entities.ToList().FirstOrDefault(u => u.Name.Trim().ToUpper() == user.Name.Trim().ToUpper()
                 && u.UPassword.Trim().ToUpper() == user.UPassword.Trim().ToUpper());
                //if (entity != null)
                //{
                //    entity.VendorDetails = null;
                //    entity.PersonalDetail = null;
                //    entity.UserTypeDetail = null;
                //    entity.VendorDetails = null;
                //}
                return entity;
            }
        }

        public async Task<bool> ChangePassword(UserDetail user)
        {
            UserDetail entityResult = null, entity = null;
            using (var iRepositoryVS = new RepositoryVS<UserDetail>())
            {
                var entities = await iRepositoryVS.Read();
                entity = entities.ToList().AsEnumerable().FirstOrDefault(u => u.Name.Trim().ToUpper() == user.Name.Trim().ToUpper() &&
               u.CommunicationDetail.Email1.Trim().ToUpper() == user.CommunicationDetail.Email1.Trim().ToUpper());

                if (entity == null) return false;

                entity.UPassword = user.UPassword;
                entity.CommunicationDetail = null;
                entity.PersonalDetail = null;
                entity.UserTypeDetail = null;
                entity.VendorDetails = null;
                entityResult = await iRepositoryVS.Upsert(entity);
            } 

            if (entityResult != null)
                return true;
            else
                return false;
        }
    }
}
