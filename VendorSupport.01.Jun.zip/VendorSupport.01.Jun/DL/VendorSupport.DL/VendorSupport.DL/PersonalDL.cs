﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.DL.Interfaces;
using VendorSupport.Entities;
using VendorSupport.Repositories;

namespace VendorSupport.DL
{
    public class PersonalDL : BaseDL, IPersonalDL
    {
        public async Task<PersonalDetail> Create(PersonalDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<PersonalDetail>())
            {
                return await iRepositoryVS.Create(entity);
            }
        }

        public async Task<bool> Delete(PersonalDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<PersonalDetail>())
            {
                return await iRepositoryVS.Delete(entity);
            }
        }

        public async Task<IEnumerable<PersonalDetail>> Read(PersonalDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<PersonalDetail>())
            {
                return await iRepositoryVS.Read(entity);
            }
        }

        public async Task<IEnumerable<PersonalDetail>> Read()
        {
            using (var iRepositoryVS = new RepositoryVS<PersonalDetail>())
            {
                return await iRepositoryVS.Read();
            }
        }



        public async Task<PersonalDetail> Upsert(PersonalDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<PersonalDetail>())
            {
                return await iRepositoryVS.Upsert(entity);
            }
        }

        public async Task<PersonalDetail> Read(decimal code)
        {
            using (var iRepositoryVS = new RepositoryVS<PersonalDetail>())
            {
                var result = await iRepositoryVS.Read();
                return result.FirstOrDefault(e => e.Code == code);
            }
        }
    }
}
