﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.DL.Interfaces;
using VendorSupport.Entities;
using VendorSupport.Repositories;

namespace VendorSupport.DL
{
   public class CountryDL : BaseDL, ICountryDL
    {
        public async Task<CountryDetail> Create(CountryDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<CountryDetail>())
            {
                return await iRepositoryVS.Create(entity);
            }
        }

        public async Task<bool> Delete(CountryDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<CountryDetail>())
            {
                return await iRepositoryVS.Delete(entity);
            }
        }

        public async Task<IEnumerable<CountryDetail>> Read(CountryDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<CountryDetail>())
            {
                return await iRepositoryVS.Read(entity);
            }
        }

        public async Task<IEnumerable<CountryDetail>> Read()
        {
            using (var iRepositoryVS = new RepositoryVS<CountryDetail>())
            {
                return await iRepositoryVS.Read();
            }
        }



        public async Task<CountryDetail> Upsert(CountryDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<CountryDetail>())
            {
                return await iRepositoryVS.Upsert(entity);
            }
        }


        public async Task<CountryDetail> Read(decimal code)
        {
            using (var iRepositoryVS = new RepositoryVS<CountryDetail>())
            {
                var result = await iRepositoryVS.Read();
                return result.FirstOrDefault(e => e.Code == code);
            }
        }
    }
}