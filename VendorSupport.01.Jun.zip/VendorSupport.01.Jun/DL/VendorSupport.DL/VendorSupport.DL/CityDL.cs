﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.DL.Interfaces;
using VendorSupport.Entities;
using VendorSupport.Repositories;

namespace VendorSupport.DL
{
  public  class CityDL : BaseDL, ICityDL
    {
        public async Task<CityDetail> Create(CityDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<CityDetail>())
            {
                entity.AreaDetails = null;
                entity.StateDetail = null;
                return await iRepositoryVS.Create(entity);
            }
        }

        public async Task<bool> Delete(CityDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<CityDetail>())
            {
                return await iRepositoryVS.Delete(entity);
            }
        }

        public async Task<IEnumerable<CityDetail>> Read(CityDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<CityDetail>())
            {
                var entities = await iRepositoryVS.Read(entity); 
                return entities.ToList();
            }
        }

        public async Task<IEnumerable<CityDetail>> Read()
        {
            using (var iRepositoryVS = new RepositoryVS<CityDetail>())
            {
                var enities= await iRepositoryVS.Read();
                return enities.ToList();
            }
        }



        public async Task<CityDetail> Upsert(CityDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<CityDetail>())
            {
                return await iRepositoryVS.Upsert(entity);
            }
        }


        public async Task<CityDetail> Read(decimal code)
        {
            using (var iRepositoryVS = new RepositoryVS<CityDetail>())
            {
                var result = await iRepositoryVS.Read();
                return result.FirstOrDefault(e => e.Code == code);
            }
        }
    }
}