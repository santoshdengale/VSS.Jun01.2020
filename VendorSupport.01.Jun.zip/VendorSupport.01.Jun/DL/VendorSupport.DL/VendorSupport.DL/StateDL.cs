﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.DL.Interfaces;
using VendorSupport.Entities;
using VendorSupport.Repositories;

namespace VendorSupport.DL
{
    public class StateDL : BaseDL, IStateDL
    {
        public async Task<StateDetail> Create(StateDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<StateDetail>())
            {
                entity.CountryDetail = null;
                entity.DistrictDetails = null;

                return await iRepositoryVS.Create(entity);
            }
        }

        public async Task<bool> Delete(StateDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<StateDetail>())
            {
                return await iRepositoryVS.Delete(entity);
            }
        }

        public async Task<IEnumerable<StateDetail>> Read(StateDetail entity)
        {
            try
            {
                using (var iRepositoryVS = new RepositoryVS<StateDetail>())
                {
                    return await iRepositoryVS.Read(entity);
                }
            }
            catch (System.Exception ex)
            {

                throw;
            }
        }

        public async Task<IEnumerable<StateDetail>> Read()
        {
            // IQueryable<StateDetail> entities;
            try
            {
                using (var iRepositoryVS = new RepositoryVS<StateDetail>())
                {
                    var entities = await iRepositoryVS.Read();
                    return entities.ToList();
                }
            }
            catch (System.Exception ex)
            {
                throw;
            }
            //return entities.ToList();
        }



        public async Task<StateDetail> Upsert(StateDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<StateDetail>())
            {
                return await iRepositoryVS.Upsert(entity);
            }
        }


        public async Task<StateDetail> Read(decimal code)
        {
            using (var iRepositoryVS = new RepositoryVS<StateDetail>())
            {
                var result = await iRepositoryVS.Read();
                return result.FirstOrDefault(e => e.Code == code);
            }
        }
    }
}