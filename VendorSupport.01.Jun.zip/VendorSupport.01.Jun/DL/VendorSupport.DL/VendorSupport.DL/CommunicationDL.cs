﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.DL.Interfaces;
using VendorSupport.Entities;
using VendorSupport.Repositories;

namespace VendorSupport.DL
{
    public class CommunicationDL : BaseDL, ICommunicationDL
    {
        public async Task<CommunicationDetail> Create(CommunicationDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<CommunicationDetail>())
            {
                return await iRepositoryVS.Create(entity);
            }
        }

        public async Task<bool> Delete(CommunicationDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<CommunicationDetail>())
            {
                return await iRepositoryVS.Delete(entity);
            }
        }

        public async Task<IEnumerable<CommunicationDetail>> Read(CommunicationDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<CommunicationDetail>())
            {
                return await iRepositoryVS.Read(entity);
            }
        }

        public async Task<IEnumerable<CommunicationDetail>> Read()
        {
            using (var iRepositoryVS = new RepositoryVS<CommunicationDetail>())
            {
                return await iRepositoryVS.Read();
            }
        }



        public async Task<CommunicationDetail> Upsert(CommunicationDetail entity)
        {
            using (var iRepositoryVS = new RepositoryVS<CommunicationDetail>())
            {
                return await iRepositoryVS.Upsert(entity);
            }
        }


        public async Task<CommunicationDetail> Read(decimal code)
        {
            using (var iRepositoryVS = new RepositoryVS<CommunicationDetail>())
            {
                var result = await iRepositoryVS.Read();
                return result.FirstOrDefault(e => e.Code == code);
            }
        }
    }
}