﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.Common;
using VendorSupport.Entities;


namespace VendorSupport.DL.Interfaces
{
    public interface ICountryDL
    {
        Task<CountryDetail> Create(CountryDetail entity);

        Task<IEnumerable<CountryDetail>> Read(CountryDetail entity);

        Task<IEnumerable<CountryDetail>> Read();

        Task<CountryDetail> Read(decimal code);

        Task<CountryDetail> Upsert(CountryDetail entity);

        Task<bool> Delete(CountryDetail entity);
    }
}
