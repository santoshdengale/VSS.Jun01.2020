﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VendorSupport.Entities;

namespace VendorSupport.DL.Interfaces
{
    public interface IVendorDL
    {
        Task<VendorDetail> Create(VendorDetail entity);

        Task<IEnumerable<VendorDetail>> Read(VendorDetail entity);

        Task<IEnumerable<VendorDetail>> Read();

        Task<VendorDetail> Read(decimal code);

        Task<VendorDetail> Upsert(VendorDetail entity);

        Task<bool> Delete(VendorDetail entity);
    }
}
