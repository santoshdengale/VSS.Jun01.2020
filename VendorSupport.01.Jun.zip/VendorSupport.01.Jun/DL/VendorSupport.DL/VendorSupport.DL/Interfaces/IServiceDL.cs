﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VendorSupport.Entities;

namespace VendorSupport.DL.Interfaces
{
    public interface IServiceDL
    {
        Task<ServiceDetail> Create(ServiceDetail entity);

        Task<IEnumerable<ServiceDetail>> Read(ServiceDetail entity);

        Task<IEnumerable<ServiceDetail>> Read();
        //Task<List<ServiceDetail>> Read();

        Task<ServiceDetail> Read(decimal code);

        Task<ServiceDetail> Upsert(ServiceDetail entity);

        Task<bool> Delete(ServiceDetail entity);
    }
}
