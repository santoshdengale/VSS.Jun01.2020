﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.Common;
using VendorSupport.Entities;


namespace VendorSupport.DL.Interfaces
{
    public interface IPersonalDL
    {
        Task<PersonalDetail> Create(PersonalDetail entity);

        Task<IEnumerable<PersonalDetail>> Read(PersonalDetail entity);

        Task<IEnumerable<PersonalDetail>> Read();

        Task<PersonalDetail> Read(decimal code);

        Task<PersonalDetail> Upsert(PersonalDetail entity);

        Task<bool> Delete(PersonalDetail entity);
    }
}
