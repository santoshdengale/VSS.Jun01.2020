﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendorSupport.Common;
using VendorSupport.Entities;

namespace VendorSupport.DL.Interfaces
{
    public interface IUserDL
    {
        Task<UserDetail> Create(UserDetail user);

        Task<IEnumerable<UserDetail>> Read(UserDetail user);

        Task<IEnumerable<UserDetail>> Read();

        Task<UserDetail> Upsert(UserDetail user);

        Task<bool> Delete(UserDetail user);

        Task<UserDetail> Read(decimal code);

        Task<UserDetail> Login(UserDetail user);

        Task<bool> ChangePassword(UserDetail user);
    }
}
