﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.Common;
using VendorSupport.Entities;

namespace VendorSupport.DL.Interfaces
{
    public interface IAreaDL
    {
        Task<AreaDetail> Create(AreaDetail entity);

        Task<IEnumerable<AreaDetail>> Read(AreaDetail entity);

        Task<IEnumerable<AreaDetail>> Read();

        Task<AreaDetail> Read(decimal code);

        Task<AreaDetail> Upsert(AreaDetail entity);

        Task<bool> Delete(AreaDetail entity);
    }
}
