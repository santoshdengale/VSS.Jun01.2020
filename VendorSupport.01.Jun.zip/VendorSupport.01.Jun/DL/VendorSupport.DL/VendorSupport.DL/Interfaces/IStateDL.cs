﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VendorSupport.Entities;

namespace VendorSupport.DL.Interfaces
{
    public  interface IStateDL
    {
        Task<StateDetail> Create(StateDetail entity);

        Task<IEnumerable<StateDetail>> Read(StateDetail entity);

        Task<IEnumerable<StateDetail>> Read();

        Task<StateDetail> Read(decimal code);

        Task<StateDetail> Upsert(StateDetail entity);

        Task<bool> Delete(StateDetail entity);
    }
}
