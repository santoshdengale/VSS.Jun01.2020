﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.Entities;

namespace VendorSupport.DL.Interfaces
{
    public interface IUserTypeDL
    {
        Task<UserTypeDetail> Create(UserTypeDetail userType);

        Task<IEnumerable<UserTypeDetail>> Read(UserTypeDetail userType);

        Task<IEnumerable<UserTypeDetail>> Read();

        Task<UserTypeDetail> Read(decimal code);

        Task<UserTypeDetail> Upsert(UserTypeDetail userType);

        Task<bool> Delete(UserTypeDetail userType);
    }
}
