﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.Common;
using VendorSupport.Entities;


namespace VendorSupport.DL.Interfaces
{
    public interface ICityDL
    {
        Task<CityDetail> Create(CityDetail entity);

        Task<IEnumerable<CityDetail>> Read(CityDetail entity);

        Task<IEnumerable<CityDetail>> Read();

        Task<CityDetail> Read(decimal code);

        Task<CityDetail> Upsert(CityDetail entity);

        Task<bool> Delete(CityDetail entity);
    }
}
