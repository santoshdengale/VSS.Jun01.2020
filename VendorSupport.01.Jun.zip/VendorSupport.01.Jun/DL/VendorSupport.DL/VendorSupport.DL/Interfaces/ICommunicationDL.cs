﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.Common;
using VendorSupport.Entities;

namespace VendorSupport.DL.Interfaces
{
    public interface ICommunicationDL
    {
        Task<CommunicationDetail> Create(CommunicationDetail entity);

        Task<IEnumerable<CommunicationDetail>> Read(CommunicationDetail entity);

        Task<IEnumerable<CommunicationDetail>> Read(); 

        Task<CommunicationDetail> Read(decimal code);

        Task<CommunicationDetail> Upsert(CommunicationDetail entity);

        Task<bool> Delete(CommunicationDetail entity);
    }
}
