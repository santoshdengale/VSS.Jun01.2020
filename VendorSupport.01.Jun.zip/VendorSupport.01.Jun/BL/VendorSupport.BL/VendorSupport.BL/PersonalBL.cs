﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendorSupport.Entities;
using VendorSupport.DL.Interfaces;
using VendorSupport.DL;
using VendorSupport.Common;
using VendorSupport.BL.Interfaces;

namespace VendorSupport.BL
{
    public class PersonalBL : BaseBL, IPersonalBL
    {
        private readonly IPersonalDL iDataLayer;

        public PersonalBL()
        {
            iDataLayer = new PersonalDL();
        }

        public async Task<CRUDMessage> Create(PersonalDetail entity)
        {
            //var personalDetails = await iDataLayer.Read(entity);
            //if (personalDetails.Any())
                await iDataLayer.Create(entity);
            //else
            //{
            //    CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
            //    CRUDMessageHandler.Message = StringConstants.RECORD_ALREADY_EXIST;
            //}
            return CRUDMessageHandler;
        }

        public async Task<bool> Delete(PersonalDetail entity)
        {
            return await iDataLayer.Delete(entity);
        }

        public async Task<CRUDMessage> Delete(decimal code)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<PersonalDetail>> Read(PersonalDetail entity)
        {
            return await iDataLayer.Read(entity);
        }

        public async Task<PersonalDetail> Read(decimal code)
        {
            return await iDataLayer.Read(code);
        }

        public async Task<CRUDMessage> Upsert(PersonalDetail entity)
        {
            IEnumerable<PersonalDetail> users = await iDataLayer.Read();
            var userResult = users.FirstOrDefault(et => et.UserCode == entity.UserCode);

            entity.CreateBy = userResult.CreateBy;
            entity.CreatedDate = userResult.CreatedDate;
            entity.RowVersion = userResult.RowVersion;

            if (iDataLayer.Upsert(entity) == null)
            {
                CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
                CRUDMessageHandler.Message = StringConstants.RECORD_CREATED_UPDATE_FAILED;
            }
            return CRUDMessageHandler;
        }
    }
}
