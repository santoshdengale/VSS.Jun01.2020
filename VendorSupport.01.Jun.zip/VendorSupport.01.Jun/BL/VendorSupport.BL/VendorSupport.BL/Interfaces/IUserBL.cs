﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VendorSupport.Common;
using VendorSupport.Entities;

namespace VendorSupport.BL.Interfaces
{
    public interface IUserBL
    {
        Task<CRUDMessage> Create(UserDetail entity);

        Task<IEnumerable<UserDetail>> Read(UserDetail entity);

        Task<IEnumerable<UserDetail>> Read();

        Task<UserDetail> Read(decimal code);

        Task<CRUDMessage> Upsert(UserDetail entity);

        Task<CRUDMessage> Delete(UserDetail entity);

        Task<CRUDMessage> Delete(decimal code);

        Task<UserDetail> Login(UserDetail user);

        Task<bool> ChangePassword(UserDetail user);
    }
}
