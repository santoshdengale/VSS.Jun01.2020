﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VendorSupport.Common;
using VendorSupport.Entities;

namespace VendorSupport.BL.Interfaces
{
    public interface ICountryBL
    {
        Task<CRUDMessage> Create(CountryDetail entity);

        Task<IEnumerable<CountryDetail>> Read(CountryDetail entity);

        Task<IEnumerable<CountryDetail>> Read();

        Task<CRUDMessage> Upsert(CountryDetail entity);

        Task<CountryDetail> Read(decimal code);

        Task<CRUDMessage> Delete(CountryDetail entity);

        Task<CRUDMessage> Delete(decimal code);

    }
}
