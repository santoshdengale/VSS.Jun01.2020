﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VendorSupport.Common;
using VendorSupport.Entities;

namespace VendorSupport.BL.Interfaces
{
    public interface IPersonalBL
    {
        Task<CRUDMessage> Create(PersonalDetail entity);

        Task<bool> Delete(PersonalDetail entity);

        Task<IEnumerable<PersonalDetail>> Read(PersonalDetail entity);

        Task<PersonalDetail> Read(decimal code);

        Task<CRUDMessage> Upsert(PersonalDetail entity);

        Task<CRUDMessage> Delete(decimal code);
    }
}
