﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VendorSupport.Common;
using VendorSupport.Entities;

namespace VendorSupport.BL.Interfaces
{
  public  interface IStateBL
    {
        Task<CRUDMessage> Create(StateDetail entity);

        Task<IEnumerable<StateDetail>> Read(StateDetail entity);

        Task<IEnumerable<StateDetail>> Read();

        Task<CRUDMessage> Upsert(StateDetail entity);

        Task<StateDetail> Read(decimal code);

        Task<CRUDMessage> Delete(StateDetail entity);

        Task<CRUDMessage> Delete(decimal code);
    }
}

