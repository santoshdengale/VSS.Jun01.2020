﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VendorSupport.Common;
using VendorSupport.Entities;

namespace VendorSupport.BL.Interfaces
{
    public interface ICommunicationBL
    {
        Task<CRUDMessage> Create(CommunicationDetail entity);

        Task<CRUDMessage> Delete(CommunicationDetail entity);

        Task<IEnumerable<CommunicationDetail>> Read(CommunicationDetail entity);

        Task<CRUDMessage> Upsert(CommunicationDetail entity);

        Task<CommunicationDetail> Read(decimal code); 

        Task<CRUDMessage> Delete(decimal code);
    }
}
