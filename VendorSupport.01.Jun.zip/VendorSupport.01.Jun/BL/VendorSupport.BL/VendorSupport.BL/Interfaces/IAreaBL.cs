﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendorSupport.Common;
using VendorSupport.Entities;

namespace VendorSupport.BL.Interfaces
{
    public interface IAreaBL
    {
        Task<CRUDMessage> Create(AreaDetail entity);

        Task<IEnumerable<AreaDetail>> Read(AreaDetail entity);

        Task<IEnumerable<AreaDetail>> Read();

        Task<CRUDMessage> Upsert(AreaDetail entity);

        Task<AreaDetail> Read(decimal code);

        Task<CRUDMessage> Delete(AreaDetail entity);

        Task<CRUDMessage> Delete(decimal code);
    }
} 