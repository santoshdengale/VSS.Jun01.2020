﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VendorSupport.Common;
using VendorSupport.Entities;

namespace VendorSupport.BL.Interfaces
{
    public interface IServiceBL
    {
        Task<CRUDMessage> Create(ServiceDetail entity);

        Task<IEnumerable<ServiceDetail>> Read(ServiceDetail entity);

        //Task<IEnumerable<ServiceDetail>> Read();
        Task<List<ServiceDetail>> Read();

        Task<CRUDMessage> Upsert(ServiceDetail entity);

        Task<ServiceDetail> Read(decimal code);

        Task<CRUDMessage> Delete(ServiceDetail entity);

        Task<CRUDMessage> Delete(decimal code);
    }
}

