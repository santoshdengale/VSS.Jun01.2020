﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendorSupport.Common;
using VendorSupport.Entities;

namespace VendorSupport.BL.Interfaces
{
   public interface ICityBL
    {
        Task<CRUDMessage> Create(CityDetail entity);

        Task<IEnumerable<CityDetail>> Read(CityDetail entity);

        Task<IEnumerable<CityDetail>> Read();

        Task<CRUDMessage> Upsert(CityDetail entity);

        Task<CityDetail> Read(decimal code);

        Task<CRUDMessage> Delete(CityDetail entity);

        Task<CRUDMessage> Delete(decimal code);
    }
}