﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendorSupport.Common;
using VendorSupport.Entities;

namespace VendorSupport.BL.Interfaces
{
    public interface IUserTypeBL
    {
        Task<CRUDMessage> Create(UserTypeDetail entity);

        Task<IEnumerable<UserTypeDetail>> Read(UserTypeDetail entity);

        Task<IEnumerable<UserTypeDetail>> Read();

        Task<CRUDMessage> Upsert(UserTypeDetail entity); 

        Task<UserTypeDetail> Read(decimal code); 

        Task<CRUDMessage> Delete(UserTypeDetail entity);

        Task<CRUDMessage> Delete(decimal code);
    }
}
