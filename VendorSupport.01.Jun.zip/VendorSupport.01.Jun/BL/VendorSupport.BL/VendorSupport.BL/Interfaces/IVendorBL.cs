﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VendorSupport.Common;
using VendorSupport.Entities;

namespace VendorSupport.BL.Interfaces
{
  public  interface IVendorBL
    {
        Task<CRUDMessage> Create(VendorDetail entity);

        Task<IEnumerable<VendorDetail>> Read(VendorDetail entity);

        Task<IEnumerable<VendorDetail>> Read();

        Task<CRUDMessage> Upsert(VendorDetail entity);

        Task<VendorDetail> Read(decimal code);

        Task<CRUDMessage> Delete(VendorDetail entity);

        Task<CRUDMessage> Delete(decimal code);
    }
}

