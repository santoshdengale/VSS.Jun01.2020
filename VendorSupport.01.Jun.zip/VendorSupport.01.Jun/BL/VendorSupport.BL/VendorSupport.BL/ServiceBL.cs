﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.BL.Interfaces;
using VendorSupport.Common;
using VendorSupport.DL;
using VendorSupport.DL.Interfaces;
using VendorSupport.Entities;

namespace VendorSupport.BL
{
    public class ServiceBL : BaseBL, IServiceBL
    {
        private readonly IServiceDL iDataLayer;

        public ServiceBL(IServiceDL iDLayer)
        {
            // iDataLayer = new ServiceDL();
            iDataLayer = iDLayer;
        }

        public async Task<CRUDMessage> Create(ServiceDetail entity)
        {
            try
            {
                var entities = await iDataLayer.Read();
                var rEntity = entities.FirstOrDefault(e => e.Name.ToUpper().Trim() == entity.Name.Trim().ToUpper());
                if (rEntity == null)
                    await iDataLayer.Create(entity);
                else
                {
                    CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
                    CRUDMessageHandler.Message = StringConstants.RECORD_ALREADY_EXIST;
                }

            }
            catch (Exception ex)
            { 
            }
            return CRUDMessageHandler;
        }

        public async Task<CRUDMessage> Delete(ServiceDetail entity)
        {
            var result = await iDataLayer.Delete(entity);
            if (!result)
            {
                CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
                CRUDMessageHandler.Message = StringConstants.RECORD_ALREADY_EXIST;
            }
            return CRUDMessageHandler;
        }

        public async Task<CRUDMessage> Delete(decimal code)
        {
            //return iUserTypeDL.Delete(code);'
            return CRUDMessageHandler;
        }

        public async Task<IEnumerable<ServiceDetail>> Read(ServiceDetail entity)
        {
            return await iDataLayer.Read(entity);
        }

        public async Task<List<ServiceDetail>> Read()
        {
            IEnumerable<ServiceDetail> entites = await iDataLayer.Read();
            return entites.ToList();
        }

        public async Task<ServiceDetail> Read(decimal code)
        {
            return await iDataLayer.Read(code);
        }

        public async Task<CRUDMessage> Upsert(ServiceDetail entity)
        {
            IEnumerable<ServiceDetail> entities = await iDataLayer.Read();
            var userTypeResult = entities.FirstOrDefault(ut => ut.Code == entity.Code);

            entity.CreateBy = userTypeResult.CreateBy;
            entity.CreatedDate = userTypeResult.CreatedDate;
            entity.RowVersion = userTypeResult.RowVersion;

            if (iDataLayer.Upsert(entity) == null)
            {
                CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
                CRUDMessageHandler.Message = "Error to update user";
            }
            return CRUDMessageHandler;
        }
    }
}