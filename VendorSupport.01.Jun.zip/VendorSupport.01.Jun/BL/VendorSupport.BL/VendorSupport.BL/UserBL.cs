﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.BL.Interfaces;
using VendorSupport.Common;
using VendorSupport.DL;
using VendorSupport.DL.Interfaces;
using VendorSupport.Entities;

namespace VendorSupport.BL
{
    public class UserBL : BaseBL, IUserBL
    {
        private readonly IUserDL iUserDL;
        //private readonly ICommunicationDL iCommDL;
        //private readonly IPersonalDL iPersonalDL;

        public UserBL()
        {
            iUserDL = new UserDL();
        }

        public async Task<CRUDMessage> Create(UserDetail entity)
        {
            var entities = await iUserDL.Read();
            var rEntity = entities.FirstOrDefault(e => e.Name.ToUpper().Trim() == entity.Name.Trim().ToUpper()
            && e.CommunicationDetail.Email1.ToUpper().Trim() == entity.CommunicationDetail.Email1.Trim().ToUpper());
            if (rEntity == null)
                await iUserDL.Create(entity);
            else
            {
                CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
                CRUDMessageHandler.Message = StringConstants.RECORD_ALREADY_EXIST;
            }
            return CRUDMessageHandler;
        }

        public async Task<CRUDMessage> Delete(UserDetail entity)
        {
            var result = await iUserDL.Delete(entity);
            if (!result)
            {
                CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
                CRUDMessageHandler.Message = StringConstants.RECORD_DELETE_FAILED;
            }
            return CRUDMessageHandler;
        }

        public async Task<CRUDMessage> Delete(decimal code)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<UserDetail>> Read(UserDetail entity)
        {
            return await iUserDL.Read(entity);
        }

        public async Task<IEnumerable<UserDetail>> Read()
        {
            try
            {

                return await iUserDL.Read();
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public async Task<UserDetail> Read(decimal code)
        {
            return await iUserDL.Read(code);
        }

        public async Task<CRUDMessage> Upsert(UserDetail entity)
        {
            //Upsert Communication
            //new CommunicationBL().Upsert(entity.CommunicationDetail);

            //Upsert Personal Details
            new PersonalBL().Upsert(entity.PersonalDetail);

            //Upsert User Details
            //new User().Upsert(entity.PersonalDetail);


            IEnumerable<UserDetail> users = await iUserDL.Read();
            var userResult = users.FirstOrDefault(e => e.UserCode == entity.UserCode);

            entity.CreateBy = userResult.CreateBy;
            entity.CreatedDate = userResult.CreatedDate;
            entity.RowVersion = userResult.RowVersion;

            if (iUserDL.Upsert(entity) == null)
            {
                CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
                CRUDMessageHandler.Message = "Error to update user";
            }
            return CRUDMessageHandler;
        }

        public async Task<UserDetail> Login(UserDetail user)
        {
            return await iUserDL.Login(user);
        }

        public async Task<bool> ChangePassword(UserDetail user)
        {
            return await iUserDL.ChangePassword(user);
        }
    }
}
