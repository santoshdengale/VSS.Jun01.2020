﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.BL.Interfaces;
using VendorSupport.Common;
using VendorSupport.DL;
using VendorSupport.DL.Interfaces;
using VendorSupport.Entities;

namespace VendorSupport.BL
{
    public class CommunicationBL : BaseBL, ICommunicationBL
    {
        private readonly ICommunicationDL iDataLayer;

        public CommunicationBL()
        {
            iDataLayer = new CommunicationDL();
        }

        public async Task<CRUDMessage> Create(CommunicationDetail entity)
        {
           // IEnumerable<CommunicationDetail> communications = await iDataLayer.Read();
            //if (!communications.Any())
                await iDataLayer.Create(entity);
            //else
            //{
            //    CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
            //    CRUDMessageHandler.Message = StringConstants.RECORD_ALREADY_EXIST;
            //}
            return CRUDMessageHandler;
        }

        public async Task<CRUDMessage> Delete(CommunicationDetail entity)
        {
            var result = await iDataLayer.Delete(entity);
            if (!result)
            {
                CRUDMessageHandler.Message = StringConstants.RECORD_DELETE_FAILED;
                CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
            }
            return CRUDMessageHandler;
        }

        public Task<CRUDMessage> Delete(decimal code)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<CommunicationDetail>> Read(CommunicationDetail entity)
        {
            return await iDataLayer.Read(entity);
        }

        public Task<CommunicationDetail> Read(decimal code)
        {
            return iDataLayer.Read(code);
        }

        public async Task<CRUDMessage> Upsert(CommunicationDetail entity)
        {
            IEnumerable<CommunicationDetail> users = await iDataLayer.Read();
            var userResult = users.FirstOrDefault(ut => ut.UserCode == entity.UserCode);

            entity.CreateBy = userResult.CreateBy;
            entity.CreatedDate = userResult.CreatedDate;
            entity.RowVersion = userResult.RowVersion;

            if (iDataLayer.Upsert(entity) == null)
            {
                CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
                CRUDMessageHandler.Message = "Error to update user";
            }
            return CRUDMessageHandler;
        }
    }
}
