﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.BL.Interfaces;
using VendorSupport.Common;
using VendorSupport.DL;
using VendorSupport.DL.Interfaces;
using VendorSupport.Entities;

namespace VendorSupport.BL
{
    public class CountryBL : BaseBL, ICountryBL
    {
        private readonly ICountryDL iDataLayer;

        public CountryBL()
        {
            iDataLayer = new CountryDL();
        }

        public async Task<CRUDMessage> Create(CountryDetail entity)
        {
            try
            {
                var entities = await iDataLayer.Read();
                var rEntity = entities.FirstOrDefault(e => e.Name.ToUpper().Trim() == entity.Name.Trim().ToUpper());
                if (rEntity == null)
                    await iDataLayer.Create(entity);
                else
                {
                    CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
                    CRUDMessageHandler.Message = StringConstants.RECORD_ALREADY_EXIST;
                }
            }
            catch (Exception ex)
            {

                // throw;
            }
            return CRUDMessageHandler;
        }

        public async Task<CRUDMessage> Delete(CountryDetail entity)
        {
            var result = await iDataLayer.Delete(entity);
            if (!result)
            {
                CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
                CRUDMessageHandler.Message = StringConstants.RECORD_ALREADY_EXIST;
            }
            return CRUDMessageHandler;
        }

        public async Task<CRUDMessage> Delete(decimal code)
        {
            //return iUserTypeDL.Delete(code);'
            return CRUDMessageHandler;
        }

        public async Task<IEnumerable<CountryDetail>> Read(CountryDetail entity)
        {
            return await iDataLayer.Read(entity);
        }

        public async Task<IEnumerable<CountryDetail>> Read()
        {
            return await iDataLayer.Read();
        }

        public async Task<CountryDetail> Read(decimal code)
        {
            return await iDataLayer.Read(code);
        }

        public async Task<CRUDMessage> Upsert(CountryDetail entity)
        {
            IEnumerable<CountryDetail> entities = await iDataLayer.Read();
            var userTypeResult = entities.FirstOrDefault(ut => ut.Code == entity.Code);

            entity.CreateBy = userTypeResult.CreateBy;
            entity.CreatedDate = userTypeResult.CreatedDate;
            entity.RowVersion = userTypeResult.RowVersion;

            if (iDataLayer.Upsert(entity) == null)
            {
                CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
                CRUDMessageHandler.Message = "Error to update user";
            }
            return CRUDMessageHandler;
        }
    }
}
