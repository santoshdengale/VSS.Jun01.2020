﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.BL.Interfaces;
using VendorSupport.Common;
using VendorSupport.DL;
using VendorSupport.DL.Interfaces;
using VendorSupport.Entities;

namespace VendorSupport.BL
{
    public class StateBL : BaseBL, IStateBL
    {
        private readonly IStateDL iDataLayer;

        public StateBL(IStateDL iDLayer)
        {
            iDataLayer = new StateDL();
        }

        public async Task<CRUDMessage> Create(StateDetail entity)
        {
            var entities = await iDataLayer.Read();
            var rEntity = entities.AsEnumerable().FirstOrDefault(
                e => e.Name.Trim().ToUpper() == entity.Name.Trim().ToUpper() &&
                 e.CountryCode == e.CountryCode.Value);

            if (rEntity == null)
            {
                try
                {
                    entity.CountryDetail = null;
                    entity.DistrictDetails = null;
                    await iDataLayer.Create(entity);
                }
                catch (Exception ex)
                {

                }
            }
            else
            { 
                CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
                CRUDMessageHandler.Message = StringConstants.RECORD_ALREADY_EXIST;
            }


            return CRUDMessageHandler;
        }

        public async Task<CRUDMessage> Delete(StateDetail entity)
        {
            var result = await iDataLayer.Delete(entity);
            if (!result)
            {
                CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
                CRUDMessageHandler.Message = StringConstants.RECORD_ALREADY_EXIST;
            }
            return CRUDMessageHandler;
        }

        public async Task<CRUDMessage> Delete(decimal code)
        {
            //return iUserTypeDL.Delete(code);'
            return CRUDMessageHandler;
        }

        public async Task<IEnumerable<StateDetail>> Read(StateDetail entity)
        {
            return await iDataLayer.Read(entity);
        }

        public async Task<IEnumerable<StateDetail>> Read()
        {
            return await iDataLayer.Read();
        }

        public async Task<StateDetail> Read(decimal code)
        {
            return await iDataLayer.Read(code);
        }

        public async Task<CRUDMessage> Upsert(StateDetail entity)
        {
            IEnumerable<StateDetail> entities = await iDataLayer.Read();
            var userTypeResult = entities.FirstOrDefault(ut => ut.Code == entity.Code);

            entity.CreateBy = userTypeResult.CreateBy;
            entity.CreatedDate = userTypeResult.CreatedDate;
            entity.RowVersion = userTypeResult.RowVersion;

            if (iDataLayer.Upsert(entity) == null)
            {
                CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
                CRUDMessageHandler.Message = "Error to update user";
            }
            return CRUDMessageHandler;
        }
    }
}