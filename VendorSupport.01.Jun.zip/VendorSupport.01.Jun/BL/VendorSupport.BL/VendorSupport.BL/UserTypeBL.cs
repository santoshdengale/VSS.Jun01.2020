﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.BL.Interfaces;
using VendorSupport.Common;
using VendorSupport.DL;
using VendorSupport.DL.Interfaces;
using VendorSupport.Entities;

namespace VendorSupport.BL
{
    public class UserTypeBL : BaseBL, IUserTypeBL
    {
        private readonly IUserTypeDL iUserTypeDL;

        public UserTypeBL()
        {
            iUserTypeDL = new UserTypeDL();
        }

        public async Task<CRUDMessage> Create(UserTypeDetail entity)
        {
            var entities = await iUserTypeDL.Read();
            var rEntity = entities.FirstOrDefault(e => e.Name.ToUpper().Trim() == entity.Name.Trim().ToUpper());
            if (rEntity == null)
                await iUserTypeDL.Create(entity);
            else
            {
                CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
                CRUDMessageHandler.Message = StringConstants.RECORD_ALREADY_EXIST;
            }
            return CRUDMessageHandler;
        }

        public async Task<CRUDMessage> Delete(UserTypeDetail entity)
        {
            var result = await iUserTypeDL.Delete(entity);
            if (!result)
            {
                CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
                CRUDMessageHandler.Message = StringConstants.RECORD_ALREADY_EXIST;
            }
            return CRUDMessageHandler;
        }

        public async Task<CRUDMessage> Delete(decimal code)
        {
            //return iUserTypeDL.Delete(code);'
            return CRUDMessageHandler;
        }

        public async Task<IEnumerable<UserTypeDetail>> Read(UserTypeDetail entity)
        {
            return await iUserTypeDL.Read(entity);
        }

        public async Task<IEnumerable<UserTypeDetail>> Read()
        {
            return await iUserTypeDL.Read();
        }

        public async Task<UserTypeDetail> Read(decimal code)
        {
            return await iUserTypeDL.Read(code);
        }

        public async Task<CRUDMessage> Upsert(UserTypeDetail entity)
        {
            IEnumerable<UserTypeDetail> userTypeDetails =await iUserTypeDL.Read();
            var userTypeResult = userTypeDetails.FirstOrDefault(ut => ut.Code == entity.Code);

            entity.CreateBy = userTypeResult.CreateBy;
            entity.CreatedDate = userTypeResult.CreatedDate;
            entity.RowVersion = userTypeResult.RowVersion;

            if (iUserTypeDL.Upsert(entity) == null)
            {
                CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
                CRUDMessageHandler.Message = "Error to update user";
            }
            return CRUDMessageHandler;
        }
    }
}