﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VendorSupport.BL.Interfaces;
using VendorSupport.Common;
using VendorSupport.DL;
using VendorSupport.DL.Interfaces;
using VendorSupport.Entities;


namespace VendorSupport.BL
{
    public class VendorBL : BaseBL, IVendorBL
    {
        private readonly IVendorDL iDataLayer;

        public VendorBL(IVendorDL iDLayer)
        {
            // iDataLayer = new VendorDL();
            iDataLayer = iDLayer;
        }

        public async Task<CRUDMessage> Create(VendorDetail entity)
        {
            var ServiceDetail = await iDataLayer.Read();

            var entities = ServiceDetail.FirstOrDefault(e =>
            e.PersonalDetail.FirstName.Trim().ToUpper() == entity.PersonalDetail.FirstName.Trim().ToUpper() &&
             e.PersonalDetail.LastName.Trim().ToUpper() == entity.PersonalDetail.LastName.Trim().ToUpper() &&
            e.CommunicationDetail.Mobile1 == entity.CommunicationDetail.Mobile1.Trim().ToUpper() &&
            e.CommunicationDetail.Email1 == entity.CommunicationDetail.Email1.Trim().ToUpper());

            if (entities == null)
            {
                try
                {
                    var cEntity = await new CommunicationDL().Create(entity.CommunicationDetail); 
                    entity.CommunicationDetail = null;
                    entity.UserDetail.CommunicationDetail = null; 
                    entity.CommCode = cEntity.Code;
                    entity.UserDetail.CommCode = cEntity.Code; 

                    var pEntity = await new PersonalDL().Create(entity.PersonalDetail);
                    entity.PersonalDetail = null;
                    entity.UserDetail.PersonalDetail = null;
                    entity.PersonalCode = pEntity.Code; 
                    entity.UserDetail.PersonalCode = pEntity.Code; 

                    //Create Vedor type User
                    entity.UserDetail.UserTypeCode = (short)Common.EnumUserType.Vendor;
                    entity.UserDetail.UserTypeDetail = null;
                    entity.UserDetail.VendorDetails = null;

                    entity.UserDetail.Name = pEntity.FirstName + "." + pEntity.LastName;
                    var uEntity = await new UserDL().Create(entity.UserDetail); 


                    await iDataLayer.Create(entity);
                }
                catch (Exception ex)
                {

                }
            }
            else
            {
                CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
                CRUDMessageHandler.Message = StringConstants.RECORD_ALREADY_EXIST;
            }
            return CRUDMessageHandler;
        }

        public async Task<CRUDMessage> Delete(VendorDetail entity)
        {
            var result = await iDataLayer.Delete(entity);
            if (!result)
            {
                CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
                CRUDMessageHandler.Message = StringConstants.RECORD_ALREADY_EXIST;
            }
            return CRUDMessageHandler;
        }

        public async Task<CRUDMessage> Delete(decimal code)
        {
            //return iUserTypeDL.Delete(code);'
            return CRUDMessageHandler;
        }

        public async Task<IEnumerable<VendorDetail>> Read(VendorDetail entity)
        {
            return await iDataLayer.Read(entity);
        }

        public async Task<IEnumerable<VendorDetail>> Read()
        {
            try
            {
                ////https://blogs.msdn.microsoft.com/eliofek/2012/12/12/why-do-we-get-the-function-evaluation-requires-all-threads-to-run/
                //IEnumerable<VendorDetail> entities =  await iDataLayer.Read();
                //var result = entities.AsEnumerable();
                //return result;
                return await iDataLayer.Read();
            }
            catch (Exception ex)
            { 
                throw ex;
            }
        }

        public async Task<VendorDetail> Read(decimal code)
        {
            return await iDataLayer.Read(code);
        }

        public async Task<CRUDMessage> Upsert(VendorDetail entity)
        {
            IEnumerable<VendorDetail> entities = await iDataLayer.Read();
            var userTypeResult = entities.FirstOrDefault(ut => ut.Code == entity.Code);

            entity.CreateBy = userTypeResult.CreateBy;
            entity.CreatedDate = userTypeResult.CreatedDate;
            entity.RowVersion = userTypeResult.RowVersion;

            if (iDataLayer.Upsert(entity) == null)
            {
                CRUDMessageHandler.MessageStutus = EnumMessageStutus.Invalid;
                CRUDMessageHandler.Message = "Error to update user";
            }
            return CRUDMessageHandler;
        }
    }
}